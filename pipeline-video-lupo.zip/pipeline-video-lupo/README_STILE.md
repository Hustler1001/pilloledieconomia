# Pillole di Economia — stile fisso dei video (deciso da Gen)

## STILE v2.1 "Cartoon 3D" per i personaggi (deciso da Gen il 3 novembre sera, in vigore dal 4 novembre)
Cambia SOLO lupo e narratrice. Sottotitoli, voci (lupo Isabella -25Hz, narratrice Elsa), scena 3D centrale, musica, CTA BUDGET e formato restano invariati.
- 3D stile cartone animato da canale TV per ragazzi (tipo Cartoon Network), personaggi ORIGINALI: non copiare personaggi, loghi o design esistenti.
- Toon shading a gradini netti (MeshToonMaterial + gradientMap a 3 toni), colori pieni e saturi, contorni neri puliti a spessore costante (outline a guscio rovesciato), forme arrotondate, teste e occhi grandi, sopracciglia mobili, bocca elastica, rim light, ombra morbida a terra. Più curati di prima.
- Animazioni con squash & stretch, anticipazione e rimbalzo. Espressioni ESAGERATE a tempo con la battuta (occhi strabuzzati, sopracciglio alzato, occhi al cielo, sorrisetto storto, faccia impassibile, mascella che cade).
- Identità: lupo grigio con occhi ambra; narratrice con capelli lunghi castani, occhiali tondi, foulard rosso, giacca blu.
- Il LUPO è molto più SARCASTICO: battute secche e ironiche sulla situazione, sui prezzi, sulle banche e sulle scuse (mai insulti verso persone, gruppi o pubblico), pausa ad effetto prima della battuta. La narratrice poi spiega con calma i numeri veri. Il sarcasmo non altera mai i fatti.
- Da fare nella sessione di stanotte (render3d.py e lupo_lib.py hanno ancora il look v2): materiali toon + contorni, nuove pose (parla, ascolta, sarcastico, sorpreso, occhi al cielo, sorrisetto, impassibile), scelta dell'espressione a tempo con le battute. Guardare l'anteprima degli sprite prima di usarli e salvare qui le versioni aggiornate.

## STILE v2 "cinematografico 3D" (da usare per TUTTI i video nuovi, deciso da Gen il 3 novembre)
- Personaggi in alto in 3D stilizzato (three.js): Il Lupo (scettico) e La Narratrice (donna, capelli lunghi, occhiali, foulard rosso, giacca blu). Sprite in sprites3d/ (si creano con three3d/render3d.py).
- Al centro NON più schede 2D piatte ma una VERA scena 3D (three.js + bloom) che si anima con i numeri del video: la telecamera vola attorno, le etichette numeriche sono in 3D e salgono in sincronia con la voce. Esempio fatto: "1.000 € e 30 anni" (torri di monete al 0%, 2%, 5%): three3d/world.html + gen_world.py + build_tempo.py.
- Sottotitoli grandi a 2 parole sotto la scena (parola chiave in giallo/viola), intestazione gialla "Pillole di Economia", nomi dei personaggi sotto di loro.
- Sottofondo: pad musicale soffice generato in codice + whoosh leggeri; niente click né pop. Loudness -16 LUFS, 48 kHz.
- Voci: lupo = it-IT-IsabellaNeural a -25Hz; narratrice = it-IT-ElsaNeural. Due voci diverse.
- Formato 9:16, 1080x1920, ~45-50 s. Tutto gratis (Edge TTS, Pillow, numpy, ffmpeg, three.js + Chromium). Niente strumenti a crediti.
- Opzionale: sfondi con filmati reali Pixabay (chiave API di Gen, solo se lui la dà nel task), come in build_mercati.py + stock_bg.mp4 (scurire a val*0.42 per leggibilità).

## SISTEMA A "SPEC" (3 video al giorno, introdotto il 3 novembre sera) — USA QUESTO per i video nuovi
Un solo build_tempo.py per tutti i video. Ogni video è un file spec_<nome>.py + una scena three3d/world_<nome>.html. Esempi già fatti e funzionanti: spec_mutuo.py / world_mutuo.html (anello di 25 colonne, interessi vs capitale), spec_rate.py / world_rate.html (telefono 3D + monete che cadono), spec_tasse.py / world_tasse.html (torte di monete con fetta staccata). three3d/common.js contiene la base condivisa (renderer, luci, bloom, polvere, etichette 3D drawLabel/makeLabel, setup(w,h,{colori})).
- spec_<nome>.py definisce: calcoli con assert; DATA (dict passato alla scena con setData); TTS (cartella voci), OUT (nome mp4), FRAMES (cartella fotogrammi), PAGE (html della scena), PART (etichetta serie "Il mutuo · Parte 2/3"), MARK=(riga g0, riga g1, riga f0) per i whoosh, LINES (battute), make_cfg(i,tl,total,B) che restituisce il cfg del fotogramma i per la scena (usa spec_common.sm e tok_t0 per sincronizzare con le parole).
- Fotogrammi di prova: SPEC=<nome> ONLY=3,16,30 PORT=8767 python3 gen_scene.py <nome>  poi  SPEC=<nome> FR=ftest_<nome> python3 build_tempo.py --preview 3,16,30  (immagine preview_sheet.png: controlla che le etichette 3D NON finiscano dietro i personaggi, che sono nei primi 650 px).
- Render completo: SPEC=<nome> nohup python3 gen_scene.py <nome> (720x1280, ~1 fotogramma/s, 25 min a video con 2 CPU; per più video mettili IN CODA in uno script con "while kill -0 PID" e PORT diverse solo se in parallelo; NON usare pkill -f con il nome dello script nello stesso comando).
- Montaggio: SPEC=<nome> python3 build_tempo.py  -> out/<OUT>. Dopo: ffprobe (1080x1920, ~52 s) e ebur128 (circa -16 LUFS).
- Regola di riquadratura (imparata a caro prezzo): il contenuto 3D deve stare tra y=270 e y=520 su 720 (anteprima 405x720), perché sopra ci sono i personaggi (fino a ~y 650 reali) e sotto la pillola di serie e i sottotitoli (1372-1600 reali). Mettere le etichette 3D vicino al centro dell'oggetto, mai sopra la cima di oggetti alti. Colori: gold con metalness 0.3 + emissive (255,170,30)*0.55, altrimenti sul fondo scuro diventa marrone.
- La pillola di serie PART compare sopra i sottotitoli e sparisce con la CTA.

## Serie avviate (aggiornare ogni giorno)
- "Il mutuo": Parte 1/3 (150.000 € 25 anni, rata 711,32 € al 3% vs 791,76 € al 4%); Parte 2/3 FATTA il 3/11 ("dove vanno i soldi", interessi 63.395 €, anno 1 52% interessi); Parte 3/3 = fisso o variabile (annunciata nella 2/3).
- "Rate e prestiti": Parte 1/2 FATTA il 3/11 (telefono 1.200 € a 24 rate, TAN 10%, rata 55,37 €, totale 1.329 €, +129 €, esempio calcolato); Parte 2/2 = come leggere un contratto di finanziamento (TAN, TAEG, costo totale), annunciata.
- "Cosa ti resta": Parte 1/2 FATTA il 3/11 (1.000 € di guadagno: tassa 26% -> 740 €, titoli di Stato 12,5% -> 875 €, regole verificate a novembre 2026 su money.it); Parte 2/2 = costi di fondi ed ETF, annunciata.
- Altri video già fatti: conto 10.000 € fermo e inflazione; mercati nascosti 1.000 €; 1.000 € e 30 anni.

## Come si fa un video nuovo (metodo v2 originale, ora sostituito dal sistema a spec)
1. cd three3d && npm install three@0.160.0 && python3 render3d.py  (sprite personaggi, una volta)
2. Copia fredoka-latin-700-normal.woff da @fontsource/fredoka in three3d/fredoka700.woff (serve alle etichette).
3. Per un video nuovo: crea spec_<nome>.py e three3d/world_<nome>.html copiando gli esempi sopra e adattandoli (vedi sezione SPEC).
4. La scena viene abbassata di 105 px nel montaggio per non coprire i personaggi.
5. Scheda finale CTA "BUDGET": è già in build_tempo.py (END), sovrapposta alla scena 3D che si attenua nell'ultima battuta.

## Vecchio stile v1 (solo riferimento)
build_lupo.py / build_mercati.py: schede 2D al centro (numero grande, grafico a barre, pillole) con sfondo blu e cerchi mobili. python3 build_lupo.py (3D di default per i personaggi; LUPO3D=0 per il vecchio 2D).
