sm=lambda x:(lambda c:c*c*(3-2*c))(max(0,min(1,x)))
def tok_t0(L,sub):
    for k in L["toks"]:
        if sub in k["disp"]: return k["t0"]
    raise KeyError(sub)
