import sys, os, math
sys.argv=[sys.argv[0]]
import build_tempo as B
sys.path.insert(0, os.path.join(B.WORK,"three3d"))
from render_world import run
tl,total=B.build_timeline()
sm=lambda x:(lambda c:c*c*(3-2*c))(max(0,min(1,x)))
g0,g1=B.MARKS["g0"],B.MARKS["g1"]; f0=B.MARKS["f0"]
T0=tl[-2]["end"]+B.TAIL   # la camera segue la parte di contenuto; l'ultima battuta (CTA) tiene la posa finale
n=int(total*30)+1; cfgs=[]
for i in range(n):
    t=i/30
    cfgs.append(dict(t=t,T=T0,years=30*sm((t-g0-0.3)/(g1-g0-0.6)),lab=sm((t-0.8)/1.0),
        focus=sm((t-f0+0.5)/3.0)*(1-sm((t-(T0-6))/3.5)),intro=min(1,t/3.0)*1.8))
print("frames",n,"total",total)
run(cfgs,os.path.join(B.WORK,"world_frames"),w=720,h=1280,prefix="w")
