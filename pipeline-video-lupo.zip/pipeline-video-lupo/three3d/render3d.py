import sys, os, subprocess, time, json
from playwright.sync_api import sync_playwright
from PIL import Image
HERE=os.path.dirname(os.path.abspath(__file__)); OUT=os.path.join(HERE,"..","sprites3d"); os.makedirs(OUT,exist_ok=True)
srv=subprocess.Popen([sys.executable,"-m","http.server","8765","--bind","127.0.0.1"],cwd=HERE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
SPR={"wolf":(440,420),"narr":(360,380)}
# camera: (fov, camY, camZ, tgtY)
CAM={"wolf":(24,0.0,8.2,-0.15),"narr":(24,-0.2,8.6,-0.6)}
def variants(who):
    ex=["neutral","skeptic","surprised","happy","worried"] if who=="wolf" else ["smile","surprised","serious"]
    for e in ex:
        for m in (0,1):
            for b in (0,1): yield e,m,b
only=sys.argv[1:] or ["wolf","narr"]
quick = "quick" in only
try:
    with sync_playwright() as p:
        br=p.chromium.launch(args=["--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader","--ignore-gpu-blocklist"])
        for who in [x for x in only if x in SPR]:
            w,h=SPR[who]; S=2
            pg=br.new_page(viewport={"width":w*S,"height":h*S}); pg.on("console",lambda m:print("console:",m.text))
            pg.goto("http://127.0.0.1:8765/scene.html"); pg.wait_for_function("window.ready===true",timeout=30000)
            fov,cy,cz,ty=CAM[who]; pg.evaluate(f"init({w*S},{h*S},{fov},{cy},{cz},{ty})")
            vs=list(variants(who))
            if quick: vs=[v for v in vs if v[2]==0 and v[1]==(1 if v[0] in("skeptic","happy","smile") else 0)][:4]
            for e,m,b in vs:
                pg.evaluate(f"show({json.dumps(dict(who=who,expr=e,mouth=m,blink=b))})")
                fn=os.path.join(OUT,f"{who}_{e}_{m}_{b}.png")
                pg.screenshot(path=fn,omit_background=True)
                Image.open(fn).convert("RGBA").resize((w,h),Image.LANCZOS).save(fn)
            pg.close()
        br.close()
finally: srv.terminate()
print("ok")
