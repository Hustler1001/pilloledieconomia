import sys, os, subprocess, time, json
from playwright.sync_api import sync_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
def run(cfgs, outdir, w=1080, h=1920, prefix="w", page="world.html", data=None, port=8766):
    os.makedirs(outdir, exist_ok=True)
    srv=subprocess.Popen([sys.executable,"-m","http.server",str(port),"--bind","127.0.0.1"],cwd=HERE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
    try:
        with sync_playwright() as p:
            br=p.chromium.launch(args=["--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader","--ignore-gpu-blocklist"])
            pg=br.new_page(viewport={"width":w,"height":h}); pg.on("console",lambda m:print("console:",m.text)); pg.on("pageerror",lambda e:print("ERR",e))
            pg.goto(f"http://127.0.0.1:{port}/{page}")
            if data is not None: pg.evaluate(f"setData({json.dumps(data)})")
            pg.evaluate(f"init({w},{h})"); pg.wait_for_function("window.ready===true",timeout=60000)
            t0=time.time()
            for i,c in enumerate(cfgs):
                fn=os.path.join(outdir,f"{prefix}{i:05d}.jpg")
                if os.path.exists(fn): continue
                pg.evaluate(f"frame({json.dumps(c)})")
                pg.screenshot(path=fn,type="jpeg",quality=92)
                if i%50==0: print(i,len(cfgs),f"{time.time()-t0:.0f}s",flush=True)
            br.close()
    finally: srv.terminate()
if __name__=="__main__":
    T=40.0
    cf=[dict(t=t,T=T,years=y,lab=1,focus=f,intro=1) for t,y,f in [(1,0,0),(8,6,0),(16,15,0),(24,30,0),(34,30,1),(39,30,1)]]
    t0=time.time(); import shutil; shutil.rmtree(os.path.join(HERE,"..","world_test"),ignore_errors=True); run(cf,os.path.join(HERE,"..","world_test"),w=720,h=1280,prefix="t"); print("tempo",time.time()-t0)
