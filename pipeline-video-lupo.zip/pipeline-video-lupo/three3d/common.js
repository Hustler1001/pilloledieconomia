// Base comune delle scene 3D (stile v2): renderer, luci, pavimento, polvere dorata, bloom, etichette.
import * as THREE from "three";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
export { THREE };
export const C = (r, g, b) => new THREE.Color().setRGB(r / 255, g / 255, b / 255, THREE.SRGBColorSpace);
export const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
export const sm = x => { x = clamp(x); return x * x * (3 - 2 * x); };
export const lerp = (a, b, t) => a + (b - a) * t;
export function rnd(seed) { let s = seed >>> 0; return () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296; }
export const fmtEur = v => String(Math.round(v)).replace(/\B(?=(\d{3})+(?!\d))/g, ".") + " €";

export function makeLabel(w = 640, h = 300) {
  const cv = document.createElement("canvas"); cv.width = w; cv.height = h;
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, depthTest: false }));
  sp.renderOrder = 10; sp.userData = { cv, tex };
  return sp;
}
export function drawLabel(sp, top, bot, col = "#e8ecff") {
  const { cv, tex } = sp.userData, g = cv.getContext("2d");
  g.clearRect(0, 0, cv.width, cv.height);
  g.textAlign = "center"; g.lineJoin = "round";
  g.font = "700 150px Fredoka, sans-serif"; g.lineWidth = 18; g.strokeStyle = "#0a0c26";
  g.strokeText(top, cv.width / 2, 150); g.fillStyle = col; g.fillText(top, cv.width / 2, 150);
  g.font = "700 74px Fredoka, sans-serif"; g.lineWidth = 12;
  g.strokeText(bot, cv.width / 2, 250); g.fillStyle = "#b9c0ee"; g.fillText(bot, cv.width / 2, 250);
  tex.needsUpdate = true;
}

// opts: bg [r,g,b], fog [r,g,b], grid1, grid2 (colori), key, rim (colori luci)
export async function setup(w, h, opts = {}) {
  const o = Object.assign({ bg: [6, 7, 26], fog: [10, 10, 40], grid1: [120, 90, 255], grid2: [50, 46, 130], floor: [12, 12, 36],
    key: [255, 230, 190], rim: [120, 100, 255], hemiSky: [120, 130, 255], hemiGround: [40, 20, 70], dust: [255, 215, 120] }, opts);
  const ff = new FontFace("Fredoka", "url(./fredoka700.woff)"); await ff.load(); document.fonts.add(ff);
  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(1); renderer.setSize(w, h); document.body.appendChild(renderer.domElement);
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
  const scene = new THREE.Scene();
  scene.background = C(...o.bg); scene.fog = new THREE.FogExp2(C(...o.fog), 0.045);
  const pm = new THREE.PMREMGenerator(renderer);
  scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture; scene.environmentIntensity = 0.55;
  const camera = new THREE.PerspectiveCamera(40, w / h, 0.1, 200);
  scene.add(new THREE.HemisphereLight(C(...o.hemiSky), C(...o.hemiGround), 0.7));
  const key = new THREE.DirectionalLight(C(...o.key), 2.2); key.position.set(4, 9, 6); scene.add(key);
  const rim = new THREE.DirectionalLight(C(...o.rim), 1.6); rim.position.set(-6, 5, -6); scene.add(rim);
  const floor = new THREE.Mesh(new THREE.CircleGeometry(60, 64), new THREE.MeshStandardMaterial({ color: C(...o.floor), roughness: 0.28, metalness: 0.6 }));
  floor.rotation.x = -Math.PI / 2; floor.position.y = -0.001; scene.add(floor);
  const grid = new THREE.GridHelper(80, 80, C(...o.grid1), C(...o.grid2)); grid.material.transparent = true; grid.material.opacity = 0.35; scene.add(grid);
  const r = rnd(7), N = 700, pos = new Float32Array(N * 3), ph = new Float32Array(N);
  for (let i = 0; i < N; i++) { pos[i*3] = (r() - 0.5) * 40; pos[i*3+1] = r() * 18; pos[i*3+2] = (r() - 0.5) * 40 - 6; ph[i] = r() * 6.28; }
  const pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  const dust = new THREE.Points(pg, new THREE.PointsMaterial({ color: C(...o.dust), size: 0.07, transparent: true, opacity: 0.8, depthWrite: false, blending: THREE.AdditiveBlending }));
  dust.userData = { base: pos.slice(), ph }; scene.add(dust);
  const composer = new EffectComposer(renderer); composer.setSize(w, h);
  composer.addPass(new RenderPass(scene, camera));
  composer.addPass(new UnrealBloomPass(new THREE.Vector2(w, h), 0.55, 0.7, 0.82));
  composer.addPass(new OutputPass());
  return { renderer, scene, camera, composer, dust, W: w, H: h };
}
export function updateDust(dust, t) {
  const b = dust.userData.base, p = dust.geometry.attributes.position.array;
  for (let i = 0; i < p.length / 3; i++) {
    p[i*3] = b[i*3] + Math.sin(t * 0.5 + dust.userData.ph[i]) * 0.4;
    p[i*3+1] = (b[i*3+1] + t * 0.35 * (0.4 + (i % 5) * 0.15)) % 18;
    p[i*3+2] = b[i*3+2] + Math.cos(t * 0.4 + dust.userData.ph[i]) * 0.4;
  }
  dust.geometry.attributes.position.needsUpdate = true;
}
