# Rate e prestiti - Parte 1/2: telefono da 1.200 euro a 24 rate (esempio calcolato, TAN 10%)
from spec_common import *
PRICE=1200; TAN=.10; M=24; i_=TAN/12
RATA=PRICE*i_/(1-(1+i_)**-M); TOTAL=RATA*M; EXTRA=TOTAL-PRICE
assert f"{RATA:.2f}"=="55.37" and round(TOTAL)==1329 and round(EXTRA)==129, (RATA,TOTAL,EXTRA)
print("[calcoli rate] rata",round(RATA,2),"totale",round(TOTAL),"extra",round(EXTRA))
DATA=dict(price=PRICE,rata=RATA,ratas="55,37",months=M,total=round(TOTAL),extra=round(EXTRA))
TTS="tts_rate"; OUT="pillole_telefono_a_rate.mp4"; FRAMES="frames_rate"; PAGE="world_rate.html"
PART="Rate e prestiti · Parte 1/2"; MARK=(3,3,5)
LINES=[
 dict(who="narr",wolf="neutral",narr="smile",text="Telefono da ^1.200_€|milleduecento_euro, oppure ^24_rate|ventiquattro_rate da ^55_€|cinquantacinque_euro. Conviene?"),
 dict(who="wolf",wolf="skeptic",narr="smile",text="Cinquantacinque euro? ~Pochissimo!"),
 dict(who="narr",wolf="skeptic",narr="serious",text="Con un tasso del ^10%|dieci_per_cento, la rata è di ^55,37_€|cinquantacinque_euro_e_trentasette, per ^24_mesi|ventiquattro_mesi."),
 dict(who="narr",wolf="surprised",narr="smile",text="Mese dopo mese le rate cadono, e alla fine hai pagato ^1.329_€|milletrecentoventinove_euro."),
 dict(who="wolf",wolf="surprised",narr="smile",text="Più del prezzo del ~telefono!"),
 dict(who="narr",wolf="neutral",narr="serious",text="Sì: sono ^129_€|centoventinove_euro di interessi. Guarda sempre il ^costo_totale e il ^TAEG|taeg."),
 dict(who="wolf",wolf="skeptic",narr="serious",text="E se pago tutto ~subito?"),
 dict(who="narr",wolf="worried",narr="serious",text="Se puoi, eviti gli interessi. È un ^esempio_calcolato, non un'offerta reale. Prossima puntata: leggere un ^contratto."),
 dict(who="wolf",wolf="happy",narr="smile",text="Allora guardo il ~totale, non solo la rata!"),
 dict(who="narr",wolf="happy",narr="smile",text="Scrivi nei commenti la parola ^BUDGET|badget e ti mando il foglio ^gratis."),
]
def make_cfg(i,tl,total,B):
    t=i/30; T0=tl[-2]["end"]+B.TAIL
    L3=tl[3]
    mo=24*max(0,min(1,(t-L3["start"]-0.2)/(L3["dur"]-0.9)))
    focus=sm((t-tl[5]["start"]+0.1)/1.3)
    return dict(t=t,T=T0,mo=mo,focus=focus,lab=sm((t-0.6)/1.0))
