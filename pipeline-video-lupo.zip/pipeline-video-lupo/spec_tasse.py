# Cosa ti resta - Parte 1/2: 1.000 euro di guadagno, tassa 26% vs 12,5% titoli di Stato (regole verificate a nov 2026)
from spec_common import *
GAIN=1000
assert GAIN*(1-.26)==740 and GAIN*.26==260 and GAIN*(1-.125)==875
DATA=dict(gain=GAIN,pies=[dict(rate=.26,name="tassa 26%"),dict(rate=.125,name="tassa 12,5%")])
TTS="tts_tasse"; OUT="pillole_cosa_ti_resta_tasse.mp4"; FRAMES="frames_tasse"; PAGE="world_tasse.html"
PART="Cosa ti resta · Parte 1/2"; MARK=(3,3,5)
LINES=[
 dict(who="narr",wolf="neutral",narr="smile",text="Hai guadagnato ^1.000_€|mille_euro con i tuoi risparmi. Quanto ti resta ^davvero?"),
 dict(who="wolf",wolf="skeptic",narr="smile",text="Tutti e ~mille, no?"),
 dict(who="narr",wolf="skeptic",narr="serious",text="Non sempre. Su molti guadagni finanziari in Italia c'è una tassa del ^26%|ventisei_per_cento."),
 dict(who="narr",wolf="surprised",narr="smile",text="Su ^1.000_€|mille_euro ne vanno ^260_€|duecentosessanta_euro. Ti restano ^740_€|settecentoquaranta_euro."),
 dict(who="wolf",wolf="surprised",narr="smile",text="E sui ~titoli_di_Stato?"),
 dict(who="narr",wolf="neutral",narr="smile",text="Per quelli italiani l'aliquota è del ^12,5%|dodici_virgola_cinque_per_cento: ti restano ^875_€|ottocentosettantacinque_euro."),
 dict(who="wolf",wolf="skeptic",narr="serious",text="Quindi conta anche la ~tassa, non solo il rendimento!"),
 dict(who="narr",wolf="worried",narr="serious",text="Esatto: guarda il rendimento ^netto. Le regole possono cambiare, quindi verifica. Prossima puntata: i ^costi_di_fondi_ed_ETF|costi_di_fondi_ed_eti_ef_ti."),
 dict(who="wolf",wolf="happy",narr="smile",text="Allora guardo il rendimento ~netto!"),
 dict(who="narr",wolf="happy",narr="smile",text="Scrivi nei commenti la parola ^BUDGET|badget e ti mando il foglio ^gratis."),
]
def make_cfg(i,tl,total,B):
    t=i/30; T0=tl[-2]["end"]+B.TAIL
    L3,L5=tl[3],tl[5]
    c1=sm((t-(L3["start"]+tok_t0(L3,"260")-0.15))/1.0)
    c2=sm((t-(L5["start"]+tok_t0(L5,"12,5%")-0.15))/1.0)
    return dict(t=t,T=T0,grow=sm((t-0.3)/1.3),cut1=c1,cut2=c2,lab=sm((t-0.9)/1.0))
