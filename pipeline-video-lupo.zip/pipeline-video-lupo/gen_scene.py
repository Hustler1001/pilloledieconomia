import sys, os
spec=sys.argv[1]; os.environ["SPEC"]=spec; sys.argv=[sys.argv[0]]
import build_tempo as B, importlib
S=importlib.import_module("spec_"+spec)
sys.path.insert(0, os.path.join(B.WORK,"three3d"))
from render_world import run
tl,total=B.build_timeline()
n=int(total*30)+1
cfgs=[S.make_cfg(i,tl,total,B) for i in range(n)]
print("frames",n,"total",total,flush=True)
if os.environ.get("ONLY"):   # anteprima: elenco di fotogrammi da rendere in una cartella di prova
    sel=[int(float(x)*30) for x in os.environ["ONLY"].split(",")]
    td=os.path.join(B.WORK,"ftest_"+spec); import shutil; shutil.rmtree(td,ignore_errors=True)
    run([cfgs[i] for i in sel],td,w=720,h=1280,prefix="t",page=S.PAGE,data=S.DATA,port=int(os.environ.get("PORT","8766")))
    for k,i in enumerate(sel): os.rename(os.path.join(td,f"t{k:05d}.jpg"),os.path.join(td,f"w{i:05d}.jpg"))
else:
    run(cfgs,os.path.join(B.WORK,S.FRAMES),w=720,h=1280,prefix="w",page=S.PAGE,data=S.DATA,port=int(os.environ.get("PORT","8766")))
