# Il mutuo - Parte 2/3: dove vanno i soldi della rata (ammortamento, esempio calcolato)
import os
from spec_common import *
P=150000; r=.03/12; n=300
RATA=P*r/(1-(1+r)**-n); TOT_INT=RATA*n-P
b=P; YEARS=[]
for y in range(25):
    I=K=0
    for m in range(12):
        i=b*r; k=RATA-i; b-=k; I+=i; K+=k
    YEARS.append((I,K))
INT_SHARE=[I/(I+K) for I,K in YEARS]
assert round(RATA,2)==711.32 and round(TOT_INT)==63395 and INT_SHARE[0]>0.5 and INT_SHARE[-1]<0.02, (RATA,TOT_INT)
print("[calcoli mutuo] rata",round(RATA,2),"interessi totali",round(TOT_INT),"anno1 %",round(INT_SHARE[0]*100,1),"anno25 %",round(INT_SHARE[-1]*100,1))
DATA=dict(principal=P,interest=round(TOT_INT),intShare=INT_SHARE)
TTS="tts_mutuo"; OUT="pillole_mutuo_dove_vanno_i_soldi.mp4"; FRAMES="frames_mutuo2"; PAGE="world_mutuo.html"
PART="Il mutuo · Parte 2/3"; MARK=(2,3,5)
LINES=[
 dict(who="narr",wolf="neutral",narr="smile",text="Paghi ^711_€|settecentoundici_euro al mese di mutuo. Ma dove vanno ^davvero?"),
 dict(who="wolf",wolf="skeptic",narr="smile",text="A ridurre il ~debito, no?"),
 dict(who="narr",wolf="skeptic",narr="serious",text="Non tutta. Su ^150.000_€|centocinquantamila_euro al ^3%|tre_per_cento in ^25_anni|venticinque_anni, nel ^primo anno più di metà della rata sono ^interessi."),
 dict(who="narr",wolf="surprised",narr="smile",text="Poi gli interessi ^scendono, e il capitale ^sale. Nell'ultimo anno gli interessi sono meno del ^2%|due_per_cento."),
 dict(who="wolf",wolf="surprised",narr="smile",text="Quindi all'inizio pago soprattutto ~interessi!"),
 dict(who="narr",wolf="neutral",narr="smile",text="Esatto. In totale gli interessi sono ^63.395_€|sessantatremilatrecentonovantacinque_euro, oltre ai soldi prestati."),
 dict(who="wolf",wolf="skeptic",narr="serious",text="E se ~rimborso prima?"),
 dict(who="narr",wolf="worried",narr="serious",text="Gli interessi futuri calano. ^Controlla il contratto. Prossima puntata: ^fisso_o_variabile?"),
 dict(who="wolf",wolf="happy",narr="smile",text="Allora leggo bene il ~piano_di_ammortamento!"),
 dict(who="narr",wolf="happy",narr="smile",text="Scrivi nei commenti la parola ^BUDGET|badget e ti mando il foglio ^gratis."),
]
def make_cfg(i,tl,total,B):
    t=i/30; T0=tl[-2]["end"]+B.TAIL
    L2,L3=tl[2],tl[3]
    tp=L2["start"]+tok_t0(L2,"primo")-0.2
    year=sm((t-tp)/1.4)*1 + 24*sm((t-L3["start"]-0.15)/(L3["dur"]-0.6))
    focus=sm((t-tl[5]["start"]+0.2)/1.4)
    return dict(t=t,T=T0,year=min(25,year),focus=focus,lab=sm((t-0.9)/1.0))
