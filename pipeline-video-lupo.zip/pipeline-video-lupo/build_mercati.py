#!/usr/bin/env python3
"""Costruisce un video 9:16 'lupo scettico' interamente con strumenti gratuiti.
Uso: python3 build_lupo.py [--preview t1,t2,...] [--tts-only]"""
import asyncio, json, os, re, ssl, subprocess, sys, math, wave
import numpy as np
import aiohttp, edge_tts
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lupo_lib import *

WORK = os.path.dirname(os.path.abspath(__file__))
TTS_DIR = os.path.join(WORK, "tts_mercati"); os.makedirs(TTS_DIR, exist_ok=True)
OUT_DIR = os.path.join(WORK, "out"); os.makedirs(OUT_DIR, exist_ok=True)
VOICES = {"narr": "it-IT-ElsaNeural", "wolf": "it-IT-IsabellaNeural"}
PITCH = {"narr": "+0Hz", "wolf": "-25Hz"}
FPS = 30
RATE = "+6%"
SR = 44100

# ----------------------------------------------------------------------------- calcoli verificati
def eur(x): return f"{int(round(x)):,}".replace(",", ".") + " €"
TARGET = 1000.0
RATES = [0.02, 0.05, 0.10]
CAPS = [TARGET / r for r in RATES]            # capitale necessario per 1.000 € di profitto in un anno
print("[calcoli] capitale necessario:", [eur(c) for c in CAPS])
assert [eur(c) for c in CAPS] == ["50.000 €", "20.000 €", "10.000 €"], CAPS
assert round(100 * TARGET / 1000) == 100       # con 1.000 € per fare +1.000 € serve +100%
for c, r in zip(CAPS, RATES): assert abs(c * r - TARGET) < 1e-6

# ----------------------------------------------------------------------------- script
# ^ = giallo, ~ = viola; "display|tts" per far leggere in lettere; _ = spazio
LINES = [
    dict(who="wolf", wolf="skeptic", narr="smile",
         text="^1.000_€|mille_euro di profitto veloce nei ~mercati_nascosti? Dove firmo?"),
    dict(who="narr", wolf="skeptic", narr="serious",
         text="Fermo. Facciamo due ^conti. Per guadagnare ^1.000_€|mille_euro in un anno, serve un ^capitale."),
    dict(who="wolf", wolf="skeptic", narr="smile",
         text="Quanto ~capitale?"),
    dict(who="narr", wolf="neutral", narr="smile",
         text="Con un rendimento del ^2%|due_per_cento: ^50.000_€|cinquantamila_euro. Al ^5%|cinque_per_cento: ^20.000_€|ventimila_euro. Al ^10%|dieci_per_cento: ^10.000_€|diecimila_euro."),
    dict(who="wolf", wolf="worried", narr="smile",
         text="Io ho solo ^1.000_€|mille_euro. Voglio altri ~mille, subito!"),
    dict(who="narr", wolf="worried", narr="serious",
         text="Allora servirebbe un rendimento del ^100%|cento_per_cento. Cioè ^raddoppiare i soldi."),
    dict(who="wolf", wolf="surprised", narr="surprised",
         text="Raddoppiare ~subito?!"),
    dict(who="narr", wolf="worried", narr="serious",
         text="Chi promette guadagni ^veloci e sicuri, quasi sempre nasconde un ^rischio enorme, o una ^truffa."),
    dict(who="wolf", wolf="happy", narr="smile",
         text="Allora prima ~controllo se è autorizzato dalla ^Consob!"),
]
GAP = 0.28
LEAD = 0.3
TAIL = 2.4

def parse_tokens(text):
    toks = []
    for raw in text.split(" "):
        color = None
        if raw[0] == "^": color, raw = YEL, raw[1:]
        elif raw[0] == "~": color, raw = PURPLE, raw[1:]
        disp, _, tts = raw.partition("|")
        trail = re.search(r"[.,?!:;]+$", disp)
        trail = trail.group(0) if trail else ""
        if not tts: tts = disp
        elif trail and not re.search(r"[.,?!:;]$", tts): tts += trail
        toks.append(dict(disp=disp.replace("_", " "), tts=tts.replace("_", " "), color=color))
    return toks

# ----------------------------------------------------------------------------- TTS
async def synth(idx, text, who):
    mp3 = os.path.join(TTS_DIR, f"line{idx}.mp3"); js = os.path.join(TTS_DIR, f"line{idx}.json")
    if os.path.exists(mp3) and os.path.exists(js): return
    ctx = ssl.create_default_context(cafile="/root/.ccr/ca-bundle.crt")
    kw = {}
    px = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
    if px: kw["proxy"] = px
    for attempt in range(3):
        try:
            conn = aiohttp.TCPConnector(ssl=ctx)
            c = edge_tts.Communicate(text, VOICES[who], rate=RATE, pitch=PITCH[who], boundary="WordBoundary", connector=conn, **kw)
            wb = []
            with open(mp3, "wb") as f:
                async for ch in c.stream():
                    if ch["type"] == "audio": f.write(ch["data"])
                    elif ch["type"] == "WordBoundary":
                        wb.append(dict(t=ch["offset"] / 1e7, d=ch["duration"] / 1e7, text=ch["text"]))
            json.dump(wb, open(js, "w"))
            return
        except Exception as e:
            print("tts retry", idx, e); await asyncio.sleep(2)
    raise RuntimeError("TTS fallito")

def dur(path):
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path]).decode().strip())

def letters(s): return re.sub(r"[^a-zàèéìòù0-9]", "", s.lower())

MARKS = {}

def build_timeline():
    t = LEAD
    tl = []
    for i, ln in enumerate(LINES):
        toks = parse_tokens(ln["text"])
        tts_text = " ".join(k["tts"] for k in toks)
        asyncio.run(synth(i, tts_text, ln['who']))
        mp3 = os.path.join(TTS_DIR, f"line{i}.mp3")
        wb = json.load(open(os.path.join(TTS_DIR, f"line{i}.json")))
        d = dur(mp3)
        # allinea i token ai confini di parola (per lunghezza in lettere, robusto a spezzature diverse)
        total_tok = sum(len(letters(k["tts"])) for k in toks)
        total_wb = sum(len(letters(w["text"])) for w in wb)
        if wb and abs(total_wb - total_tok) <= 0.2 * total_tok:
            cum_t, j, cum_b = 0, 0, 0
            for k in toks:
                cum_t += len(letters(k["tts"]))
                first = j
                while j < len(wb) and cum_b + len(letters(wb[j]["text"])) <= cum_t + 1 and cum_b < cum_t:
                    cum_b += len(letters(wb[j]["text"])); j += 1
                if j == first and j < len(wb):  # almeno una parola
                    cum_b += len(letters(wb[j]["text"])); j += 1
                k["t0"] = wb[min(first, len(wb) - 1)]["t"]
                k["t1"] = wb[min(max(j - 1, first), len(wb) - 1)]["t"] + wb[min(max(j - 1, first), len(wb) - 1)]["d"]
        else:
            print("  [avviso] allineamento proporzionale riga", i)
            acc = 0
            for k in toks:
                n = len(letters(k["tts"])); k["t0"] = d * acc / total_tok; acc += n; k["t1"] = d * acc / total_tok
        words = [(w["t"], w["t"] + w["d"]) for w in wb] or [(0, d)]
        tl.append(dict(i=i, start=t, dur=d, end=t + d, toks=toks, words=words, **{k: ln[k] for k in ("who", "wolf", "narr")}))
        t += d + GAP
    total = tl[-1]["end"] + TAIL
    g = tl[3]
    for key, label in (("r2", "2%"), ("r5", "5%"), ("r10", "10%")):
        MARKS[key] = g["start"] + next(k["t0"] for k in g["toks"] if k["disp"] == label)
    return tl, total

# ----------------------------------------------------------------------------- card (riquadro centrale)
def center_text(d, y, text, fnt, fill, W_=W):
    w = d.textlength(text, font=fnt); d.text(((W_ - w) / 2, y), text, font=fnt, fill=fill)

CARD_Y0, CARD_H = 700, 560   # regione verticale riservata alle card

def draw_label(d, text, y=22):
    center_text(d, y, text, font(F_FRED6, 46), (235, 240, 252))

def draw_bignum(layer, text, y, color=YEL, size=205, unit=None):
    d = ImageDraw.Draw(layer)
    fnt = font(F_MONT9, size)
    w = d.textlength(text, font=fnt)
    d.text(((W - w) / 2, y), text, font=fnt, fill=color)

def draw_item(layer, y, icon, text, border, h=148, fsz=44):
    card = rounded_card((920, h), border=border, bw=5, r=50)
    layer.alpha_composite(card, (80, y))
    d = ImageDraw.Draw(layer)
    ic = ICONS[icon](84)
    layer.alpha_composite(ic, (125, y + (h - 84) // 2))
    d.text((245, y + h / 2 + 2), text, font=font(F_FRED7, fsz), fill=WHITE, anchor="lm")

def count_val(a, b, tl, t0, t1):
    p = ease_out_cubic((tl - t0) / (t1 - t0))
    return lerp(a, b, p)

def render_card(kind, tl, t_abs=0.0, t0=0.0):
    """Disegna il contenuto di una card al tempo locale tl (secondi dalla comparsa)."""
    layer = Image.new("RGBA", (W, CARD_H), (0, 0, 0, 0)); d = ImageDraw.Draw(layer)
    if kind == "A":
        draw_label(d, "Nei mercati nascosti")
        draw_bignum(layer, "+1.000 €", 80, size=190)
        p = pill("profitto veloce (promesso)", color=RED); layer.alpha_composite(p, ((W - p.width) // 2, 345))
    elif kind == "B":
        draw_label(d, "Obiettivo")
        draw_bignum(layer, "1.000 €", 80, size=200)
        p = pill("di profitto in 1 anno"); layer.alpha_composite(p, ((W - p.width) // 2, 345))
    elif kind == "C":  # capitale necessario (scala intera da zero)
        draw_label(d, "Capitale per guadagnare 1.000 € in 1 anno")
        base_y, maxh, bw = 405, 260, 220
        xs = [110, 430, 750]; names = ["Al 2%", "Al 5%", "Al 10%"]
        starts = [MARKS["r2"] - 0.15, MARKS["r5"] - 0.15, MARKS["r10"] - 0.15]
        d.line([(80, base_y), (1000, base_y)], fill=(80, 95, 140), width=4)
        for i in range(3):
            if t_abs < starts[i]: continue
            p = ease_out_cubic((t_abs - starts[i]) / 0.8)
            h_rem = max(6, maxh * CAPS[i] / CAPS[0] * p); x = xs[i]
            d.rounded_rectangle([x, base_y - h_rem, x + bw, base_y], radius=min(22, int(h_rem / 2)), fill=YEL + (255,))
            d.rectangle([x, base_y - 12, x + bw, base_y], fill=YEL + (255,))
            lab = eur(CAPS[i] * p); fl = font(F_FRED7, 44); w = d.textlength(lab, font=fl)
            d.text((x + bw / 2 - w / 2, base_y - h_rem - 60), lab, font=fl, fill=WHITE)
            fn = font(F_FRED5, 36); w = d.textlength(names[i], font=fn)
            d.text((x + bw / 2 - w / 2, base_y + 16), names[i], font=fn, fill=(200, 210, 235))
    elif kind == "D":
        draw_label(d, "E se parti da poco?")
        draw_item(layer, 100, "coin", "Capitale: 1.000 €", YEL_D)
        if tl > 1.4:
            a = ease_out_back((tl - 1.4) / 0.35)
            sub = Image.new("RGBA", (W, 160), (0, 0, 0, 0)); draw_item(sub, 0, "bank", "Voglio: +1.000 € subito", RED, h=148)
            s_ = max(0.01, a); sub = sub.resize((int(W * s_), max(1, int(160 * s_))), Image.LANCZOS)
            layer.alpha_composite(sub, ((W - sub.width) // 2, 285 + (160 - sub.height) // 2))
    elif kind == "E":
        draw_label(d, "Rendimento necessario")
        draw_bignum(layer, "+100%", 70, size=240, color=RED)
        p = pill("= raddoppiare i soldi"); layer.alpha_composite(p, ((W - p.width) // 2, 385))
    elif kind == "F":
        draw_label(d, "Se te lo promettono...")
        draw_item(layer, 100, "coin", "Guadagno veloce e sicuro", YEL_D, fsz=42)
        if tl > 1.2:
            a = ease_out_back((tl - 1.2) / 0.35)
            sub = Image.new("RGBA", (W, 160), (0, 0, 0, 0)); draw_item(sub, 0, "down", "Rischio di perdere tutto", RED, fsz=42)
            s_ = max(0.01, a); sub = sub.resize((int(W * s_), max(1, int(160 * s_))), Image.LANCZOS)
            layer.alpha_composite(sub, ((W - sub.width) // 2, 285 + (160 - sub.height) // 2))
    elif kind == "END":
        f1, f2 = font(F_FRED7, 84), font(F_FRED7, 84)
        center_text(d, 10, "Pillole di", f1, YEL); center_text(d, 100, "Economia", font(F_FRED7, 110), YEL)
        center_text(d, 245, "Segui per la prossima notizia", font(F_FRED5, 42), (235, 240, 252))
        p = pill("Esempi ipotetici, non è consulenza · Verifica su consob.it", fnt=font(F_FRED5, 28), color=(190, 200, 225), pad=(26, 12))
        layer.alpha_composite(p, ((W - p.width) // 2, 345))
    return layer

CARD_PLAN = [  # (kind, prima riga, ultima riga)
    ("A", 0, 0), ("B", 1, 2), ("C", 3, 3), ("D", 4, 4), ("E", 5, 6), ("F", 7, 7), ("END", 8, 8),
]

# ----------------------------------------------------------------------------- frame
BASE, OVER, C1, C2 = make_layers()
SUB_FONT = font(F_FRED7, 92)

def chunk_tokens(toks):
    chunks, cur = [], []
    for k in toks:
        cur.append(k)
        if len(cur) >= 2 or re.search(r"[.,?!:;]$", k["disp"]):
            chunks.append(cur); cur = []
    if cur: chunks.append(cur)
    return chunks

def draw_subtitle(frame, toks, scale=1.0):
    d = ImageDraw.Draw(frame)
    fnt = font(F_FRED7, int(92 * scale))
    gap = 24
    widths = [d.textlength(k["disp"], font=fnt) for k in toks]
    total = sum(widths) + gap * (len(toks) - 1)
    while total > 980 and fnt.size > 60:
        fnt = font(F_FRED7, fnt.size - 4)
        widths = [d.textlength(k["disp"], font=fnt) for k in toks]; total = sum(widths) + gap * (len(toks) - 1)
    x = (W - total) / 2
    for k, w in zip(toks, widths):
        shadow_text(frame, (x, 1500), k["disp"], fnt, k["color"] or WHITE, stroke=8)
        x += w + gap

def active_line(tl, t):
    for L in tl:
        if L["start"] - 0.05 <= t < L["end"] + GAP * 0.9: return L
    return None

def render_frame(tl, total, t, card_cache, bg=None):
    f = BASE.copy() if bg is None else Image.blend(bg.convert('RGB'), BASE.convert('RGB'), 0.22)
    if bg is None: f.paste(C1, (int(870 - 250 + 16 * math.sin(2 * math.pi * t / 8.0)), int(220 - 280 + 10 * math.sin(2 * math.pi * t / 6.0 + 1))), C1)
    if bg is None: f.paste(C2, (int(120 - 380 + 14 * math.sin(2 * math.pi * t / 9.0 + 2)), int(1800 - 380 + 12 * math.sin(2 * math.pi * t / 7.0))), C2)
    f.paste(OVER, (0, 0), OVER)
    L = active_line(tl, t)
    speaker = L["who"] if L and t <= L["end"] + 0.12 else None
    # espressioni: l'ultima riga iniziata
    cur = None
    for X in tl:
        if X["start"] - 0.05 <= t: cur = X
    wolf_e = cur["wolf"] if cur else "neutral"; narr_e = cur["narr"] if cur else "smile"
    if cur is None: wolf_e, narr_e = "skeptic", "smile"
    # alone di chi parla
    if speaker == "wolf": f.paste(glow_sprite("wolf"), (40, 220), glow_sprite("wolf"))
    elif speaker == "narr": f.paste(glow_sprite("narr"), (660, 215), glow_sprite("narr"))
    # bocca
    def mouth_open(who):
        if speaker != who or not L: return 0
        lt = t - L["start"]
        for (a, b) in L["words"]:
            if a - 0.02 <= lt <= b + 0.03:
                return 1 if int((lt - a) * 9) % 2 == 0 else 0
        return 0
    # battito di ciglia
    blink_w = (t % 3.4) < 0.12
    blink_n = ((t + 1.3) % 4.1) < 0.12
    bob_w = 6 * math.sin(2 * math.pi * t / 2.2) if speaker == "wolf" else 3 * math.sin(2 * math.pi * t / 2.8)
    bob_n = 6 * math.sin(2 * math.pi * t / 2.2 + 1) if speaker == "narr" else 3 * math.sin(2 * math.pi * t / 2.8 + 1)
    ws = wolf(wolf_e, mouth_open("wolf"), blink_w); ns = narrator(narr_e, mouth_open("narr"), blink_n)
    f.paste(ws, (10, int(190 + bob_w)), ws); f.paste(ns, (670, int(255 + bob_n)), ns)
    # card: ogni card resta fino alla comparsa della successiva (dissolvenza incrociata, nessun vuoto)
    starts = [0.0 if ci == 0 else tl[a]["start"] + 0.12 for ci, (_, a, _) in enumerate(CARD_PLAN)]
    for ci, (kind, a, b) in enumerate(CARD_PLAN):
        t0 = starts[ci]
        t1 = starts[ci + 1] if ci + 1 < len(CARD_PLAN) else total + 1
        if not (t0 <= t < t1 + 0.2): continue
        local = t - t0
        layer = render_card(kind, local, t, t0)
        pop = ease_out_back(local / 0.38)
        alpha = clamp(local / 0.18) * (1 - clamp((t - t1) / 0.2))
        sc = lerp(0.86, 1.0, clamp(pop, 0, 1.15)) if local < 0.38 else 1.0
        if abs(sc - 1) > 0.002:
            layer = layer.resize((int(W * sc), int(CARD_H * sc)), Image.LANCZOS)
        if alpha < 0.999:
            a_ch = layer.getchannel("A").point(lambda v: int(v * alpha)); layer.putalpha(a_ch)
        f.paste(layer, ((W - layer.width) // 2, CARD_Y0 + (CARD_H - layer.height) // 2), layer)
    # sottotitoli: gruppi da 2 parole, mostrati dall'inizio della prima parola
    if L and L["start"] <= t <= L["end"] + 0.25:
        lt = t - L["start"]
        shown = None
        for ch in chunk_tokens(L["toks"]):
            if lt >= ch[0]["t0"] - 0.03: shown = ch
        if shown:
            age = lt - shown[0]["t0"]
            sc = 0.9 + 0.1 * clamp(ease_out_back(age / 0.14), 0, 1.2) if age < 0.14 else 1.0
            draw_subtitle(f, shown, sc)
    return f

# ----------------------------------------------------------------------------- audio
def decode_mp3(path):
    raw = subprocess.check_output(["ffmpeg", "-v", "error", "-i", path, "-f", "f32le", "-ac", "1", "-ar", str(SR), "-"])
    return np.frombuffer(raw, dtype=np.float32)

def whoosh(dur_s=0.5, seed=1):
    rng = np.random.default_rng(seed)
    n = int(dur_s * SR); x = rng.standard_normal(n).astype(np.float32)
    y = np.zeros(n, dtype=np.float32); prev = 0.0
    for i in range(n):
        p = i / n; a = 0.02 + 0.5 * math.sin(math.pi * min(1, p * 1.1)) ** 2   # filtro che si apre e si chiude
        prev = prev + a * (x[i] - prev); y[i] = prev
    env = np.sin(np.pi * np.linspace(0, 1, n)) ** 1.6
    y *= env; y /= (np.abs(y).max() + 1e-9)
    return y

def build_audio(tl, total, path):
    n = int((total + 0.2) * SR); mix = np.zeros(n, dtype=np.float32)
    for L in tl:
        a = decode_mp3(os.path.join(TTS_DIR, f"line{L['i']}.mp3"))
        s = int(L["start"] * SR); mix[s:s + len(a)] += a[: n - s]
    voice_peak = np.abs(mix).max()
    # whoosh leggeri solo sui momenti chiave: prima card, rivelazione del calo, card finale
    for kind, a, b in CARD_PLAN:
        if kind in ("A", "C", "END"):
            s = int((tl[a]["start"] + 0.05) * SR); w = whoosh(0.45, seed=hash(kind) % 1000) * 0.10 * voice_peak
            mix[s:s + len(w)] += w[: n - s]
    mix = np.clip(mix, -1, 1)
    with wave.open(path, "wb") as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SR); wf.writeframes((mix * 32767).astype(np.int16).tobytes())

# ----------------------------------------------------------------------------- main
def main():
    tl, total = build_timeline()
    print(f"[timeline] durata totale {total:.1f}s")
    for L in tl:
        print(f"  riga {L['i']} {L['who']:4s} {L['start']:5.2f}-{L['end']:5.2f}  {' '.join(k['disp'] for k in L['toks'])}")
    if "--tts-only" in sys.argv: return
    if "--preview" in sys.argv:
        ts = [float(x) for x in sys.argv[sys.argv.index("--preview") + 1].split(",")]
        bgs = {}
        for t in ts:
            raw = subprocess.check_output(['ffmpeg','-v','error','-ss',f'{t:.2f}','-i',os.path.join(WORK,'stock_bg.mp4'),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-'])
            bgs[t] = Image.frombytes('RGB', (W, H), raw)
        frames = [render_frame(tl, total, t, {}, bgs[t]) for t in ts]
        cols = min(len(frames), 4); rows = math.ceil(len(frames) / cols)
        sw, sh = 405, 720
        sheet = Image.new("RGB", (sw * cols, sh * rows))
        for k, fr in enumerate(frames): sheet.paste(fr.resize((sw, sh), Image.LANCZOS), ((k % cols) * sw, (k // cols) * sh))
        sheet.save(os.path.join(WORK, "preview_sheet.png")); print("preview salvata")
        if "--full" in sys.argv:
            for k, fr in enumerate(frames): fr.save(os.path.join(WORK, f"prev_{k}.png"))
        return
    wav = os.path.join(WORK, "audio_mix.wav"); build_audio(tl, total, wav)
    out = os.path.join(OUT_DIR, "pillole_mercati_nascosti_1000_euro_reale.mp4" if os.path.exists(os.path.join(WORK,"stock_bg.mp4")) and os.environ.get("STOCK","1")!="0" else "pillole_mercati_nascosti_1000_euro.mp4")
    cmd = ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
           "-i", wav, "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-ar", "48000", "-b:a", "160k", "-movflags", "+faststart", "-shortest", out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    BGV = os.path.join(WORK, 'stock_bg.mp4')
    bgp = subprocess.Popen(['ffmpeg','-v','error','-i',BGV,'-f','rawvideo','-pix_fmt','rgb24','-'], stdout=subprocess.PIPE) if os.path.exists(BGV) and os.environ.get('STOCK','1')!='0' else None
    nfr = int(total * FPS)
    for i in range(nfr):
        bgf = None
        if bgp:
            raw = bgp.stdout.read(W * H * 3)
            if len(raw) == W * H * 3: bgf = Image.frombytes('RGB', (W, H), raw)
        fr = render_frame(tl, total, i / FPS, {}, bgf)
        p.stdin.write(fr.tobytes())
        if i % 150 == 0: print(f"  frame {i}/{nfr}", flush=True)
    p.stdin.close(); p.wait()
    print("fatto:", out)

if __name__ == "__main__":
    main()
