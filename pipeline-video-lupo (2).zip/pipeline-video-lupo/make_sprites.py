#!/usr/bin/env python3
"""Ricostruisce gli sprite 2D approvati (lupo grigio + ragazza bionda) in sprites2d/ (accanto a questo file) dai file
originali della cartella Google Drive "personaggi". Uso: python3 make_sprites.py <cartella_con_gli_originali>
Servono: lupo_cut.png, narr_cut.png (RGBA bocca chiusa), lupo_bocca_mezzo.jpg, lupo_bocca_aperta.jpg, narratrice_bocca_aperta.jpg.
Trucco: canale alpha dal ritaglio a bocca chiusa, RGB dal JPG a bocca aperta."""
import sys, os
from PIL import Image
src = sys.argv[1]; out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sprites2d"); os.makedirs(out, exist_ok=True)
def L(n): return Image.open(os.path.join(src, n)).convert("RGBA")
def with_rgb(cut, jpg):
    rgb = Image.open(os.path.join(src, jpg)).convert("RGB").resize(cut.size, Image.LANCZOS)
    r = rgb.convert("RGBA"); r.putalpha(cut.getchannel("A")); return r
w0 = L("lupo_cut.png"); n0 = L("narr_cut.png")
w0.save(f"{out}/w0.png"); n0.save(f"{out}/n0.png")
with_rgb(w0, "lupo_bocca_mezzo.jpg").save(f"{out}/w1.png"); with_rgb(w0, "lupo_bocca_aperta.jpg").save(f"{out}/w2.png")
with_rgb(n0, "narratrice_bocca_aperta.jpg").save(f"{out}/n1.png")
print("sprite pronti in", out)
