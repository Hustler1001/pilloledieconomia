"""Libreria per video 'lupo scettico' in stile Pillole di Economia.
Solo strumenti gratuiti: Pillow, numpy, ffmpeg, Edge TTS."""
import os, math, functools
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H = 1080, 1920
FD = os.path.join(os.path.dirname(os.path.abspath(__file__)), "node_modules", "@fontsource") + "/"
F_FRED6 = FD + "fredoka/files/fredoka-latin-600-normal.woff"
F_FRED7 = FD + "fredoka/files/fredoka-latin-700-normal.woff"
F_FRED5 = FD + "fredoka/files/fredoka-latin-500-normal.woff"
F_MONT9 = FD + "montserrat/files/montserrat-latin-900-normal.woff"
F_MONT8 = FD + "montserrat/files/montserrat-latin-800-normal.woff"

YEL = (255, 201, 60)
YEL_D = (250, 203, 59)
RED = (242, 107, 107)
PURPLE = (167, 139, 250)
GREEN = (52, 211, 153)
WHITE = (255, 255, 255)
CARD = (39, 50, 79)
INK = (16, 16, 40)

@functools.lru_cache(None)
def font(path, size):
    return ImageFont.truetype(path, size)

def lerp(a, b, t): return a + (b - a) * t
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def ease_out_back(t, s=1.70158):
    t = clamp(t) - 1
    return 1 + t * t * ((s + 1) * t + s)
def ease_out_cubic(t):
    t = clamp(t); return 1 - (1 - t) ** 3

# ---------------------------------------------------------------- sfondo
def make_background():
    top, bot = (10, 17, 47), (26, 41, 90)
    img = Image.new("RGB", (W, H))
    px = ImageDraw.Draw(img)
    for y in range(H):
        t = y / (H - 1)
        px.line([(0, y), (W, y)], fill=tuple(int(lerp(top[i], bot[i], t)) for i in range(3)))
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    d.ellipse([870 - 250, 220 - 280, 870 + 250, 220 + 280], fill=(24, 40, 86, 200))   # cerchio alto a destra
    d.ellipse([120 - 380, 1800 - 380, 120 + 380, 1800 + 380], fill=(58, 46, 98, 150)) # cerchio basso a sinistra
    img.paste(ov, (0, 0), ov)
    d2 = ImageDraw.Draw(img)
    hf = font(F_FRED7, 46)
    txt = "Pillole di Economia"
    w = d2.textlength(txt, font=hf)
    d2.text(((W - w) / 2, 70), txt, font=hf, fill=YEL)
    d2.rounded_rectangle([450, 143, 630, 150], radius=4, fill=YEL)
    lf = font(F_FRED6, 34)
    for cx, name in ((230, "Il Lupo"), (850, "La Narratrice")):
        w = d2.textlength(name, font=lf)
        d2.text((cx - w / 2, 628), name, font=lf, fill=(235, 240, 252))
    return img

# ---------------------------------------------------------------- lupo
SS = 3  # supersampling

def _sc(pts, s=SS): return [(x * s, y * s) for x, y in pts]

@functools.lru_cache(None)
def wolf(expr="neutral", mouth=0, blink=False):
    """expr: neutral | skeptic | surprised | happy | worried. mouth: 0 chiusa, 1 aperta.
    Sprite 440x420, centro testa a (220, 200)."""
    w, h = 440, 420
    im = Image.new("RGBA", (w * SS, h * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    ox, oy = -10, -190     # sposta le coordinate di riferimento (testa a x 230, y 410)
    def P(pts): return _sc([(x + ox, y + oy) for x, y in pts])
    fur, fur_d = (156, 163, 184), (140, 148, 170)
    # testa con orecchie
    head = [(107, 218), (232, 297), (355, 218), (381, 392), (79, 392)]
    d.polygon(P(head), fill=fur)
    d.ellipse(P([(77, 380), (383, 572)])[0] + P([(77, 380), (383, 572)])[1], fill=fur)
    # orecchie interne rosa
    d.polygon(P([(130, 277), (186, 312), (148, 346)]), fill=(244, 181, 194))
    d.polygon(P([(332, 270), (276, 312), (314, 346)]), fill=(244, 181, 194))
    # muso chiaro
    d.ellipse(P([(147, 440), (313, 574)])[0] + P([(147, 440), (313, 574)])[1], fill=(230, 235, 242))
    # guance
    ch = Image.new("RGBA", im.size, (0, 0, 0, 0)); cd = ImageDraw.Draw(ch)
    for cx in (130, 330):
        cd.ellipse(P([(cx - 26, 473), (cx + 26, 500)])[0] + P([(cx - 26, 473), (cx + 26, 500)])[1], fill=(236, 150, 170, 150))
    im.alpha_composite(ch)
    d = ImageDraw.Draw(im)
    # naso
    d.ellipse(P([(203, 455), (257, 489)])[0] + P([(203, 455), (257, 489)])[1], fill=(47, 48, 60))
    d.ellipse(P([(214, 460), (230, 468)])[0] + P([(214, 460), (230, 468)])[1], fill=(120, 124, 140))
    # occhi
    ex = (168, 291)
    ey = 418
    def brow(cx, tilt, y, thick=9, length=44):
        x0, x1 = cx - length / 2, cx + length / 2
        a = (x0, y + tilt); b = (x1, y - tilt)
        d.line(P([a, b]), fill=(41, 42, 56), width=thick * SS)
        for q in (a, b):
            r = thick / 2
            d.ellipse(P([(q[0] - r, q[1] - r), (q[0] + r, q[1] + r)])[0] + P([(q[0] - r, q[1] - r), (q[0] + r, q[1] + r)])[1], fill=(41, 42, 56))
    if blink:
        for cx in ex:
            d.arc(P([(cx - 28, ey - 14), (cx + 28, ey + 18)])[0] + P([(cx - 28, ey - 14), (cx + 28, ey + 18)])[1], 200, 340, fill=(41, 42, 56), width=7 * SS)
        brow(ex[0], 0, 372); brow(ex[1], 0, 372)
    else:
        for i, cx in enumerate(ex):
            rr = 30 if expr in ("surprised", "worried", "neutral", "happy") else 29
            d.ellipse(P([(cx - rr, ey - rr), (cx + rr, ey + rr)])[0] + P([(cx - rr, ey - rr), (cx + rr, ey + rr)])[1], fill=(255, 255, 255))
            px_ = cx + (10 if expr == "skeptic" else 0)
            py_ = ey + (8 if expr == "skeptic" else 2)
            pr = 14 if expr != "surprised" else 11
            d.ellipse(P([(px_ - pr, py_ - pr), (px_ + pr, py_ + pr)])[0] + P([(px_ - pr, py_ - pr), (px_ + pr, py_ + pr)])[1], fill=(35, 36, 48))
            d.ellipse(P([(px_ - 5, py_ - 8), (px_ + 3, py_ - 1)])[0] + P([(px_ - 5, py_ - 8), (px_ + 3, py_ - 1)])[1], fill=(255, 255, 255))
        if expr == "skeptic":
            # palpebre pesanti (coprono metà occhio) e sopracciglio alzato a destra
            for cx in ex:
                d.rectangle(P([(cx - 33, ey - 34), (cx + 33, ey - 6)])[0] + P([(cx - 33, ey - 34), (cx + 33, ey - 6)])[1], fill=fur)
                d.line(P([(cx - 32, ey - 6), (cx + 32, ey - 6)]), fill=(41, 42, 56), width=5 * SS)
            brow(ex[0], 4, 378); brow(ex[1], -9, 372)
        elif expr == "surprised":
            brow(ex[0], 6, 360); brow(ex[1], -6, 360)
        elif expr == "worried":
            brow(ex[0], -8, 366); brow(ex[1], 8, 366)
        elif expr == "happy":
            brow(ex[0], 0, 366); brow(ex[1], 0, 366)
        else:
            brow(ex[0], 0, 368); brow(ex[1], 0, 368)
    # bocca
    mx, my = 230, 536
    if mouth:
        if expr == "surprised":
            d.ellipse(P([(mx - 22, my - 12), (mx + 22, my + 24)])[0] + P([(mx - 22, my - 12), (mx + 22, my + 24)])[1], fill=(120, 50, 70))
        else:
            d.ellipse(P([(mx - 30, my - 8), (mx + 30, my + 16)])[0] + P([(mx - 30, my - 8), (mx + 30, my + 16)])[1], fill=(120, 50, 70))
            d.ellipse(P([(mx - 14, my + 4), (mx + 14, my + 14)])[0] + P([(mx - 14, my + 4), (mx + 14, my + 14)])[1], fill=(236, 130, 150))
    else:
        if expr in ("skeptic", "worried"):
            d.arc(P([(mx - 34, my - 6), (mx + 34, my + 26)])[0] + P([(mx - 34, my - 6), (mx + 34, my + 26)])[1], 205, 335, fill=(100, 45, 55), width=6 * SS)
        elif expr == "happy":
            d.arc(P([(mx - 38, my - 24), (mx + 38, my + 12)])[0] + P([(mx - 38, my - 24), (mx + 38, my + 12)])[1], 25, 155, fill=(100, 45, 55), width=6 * SS)
        else:
            d.ellipse(P([(mx - 28, my - 6), (mx + 28, my + 12)])[0] + P([(mx - 28, my - 6), (mx + 28, my + 12)])[1], fill=(120, 50, 70))
            d.ellipse(P([(mx - 12, my + 3), (mx + 12, my + 11)])[0] + P([(mx - 12, my + 3), (mx + 12, my + 11)])[1], fill=(236, 130, 150))
    return im.resize((w, h), Image.LANCZOS)

# ---------------------------------------------------------------- narratore
@functools.lru_cache(None)
def narrator(expr="smile", mouth=0, blink=False):
    """expr: smile | surprised | serious. Sprite 360x380, testa centro (180, 150), base busto a y=370."""
    w, h = 360, 380
    im = Image.new("RGBA", (w * SS, h * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    ox, oy = -670, -255
    def P(pts): return _sc([(x + ox, y + oy) for x, y in pts])
    def E(x0, y0, x1, y1, **kw):
        a = P([(x0, y0), (x1, y1)]); d.ellipse(a[0] + a[1], **kw)
    # busto
    d.pieslice(P([(685, 490), (1015, 750)])[0] + P([(685, 490), (1015, 750)])[1], 180, 360, fill=(59, 130, 246))
    d.rectangle(P([(685, 620), (1015, 640)])[0] + P([(685, 620), (1015, 640)])[1], fill=(0, 0, 0, 0))
    # camicia
    d.polygon(P([(836, 528), (864, 528), (884, 625), (816, 625)]), fill=(255, 255, 255))
    # collo
    d.rectangle(P([(828, 470), (872, 505)])[0] + P([(828, 470), (872, 505)])[1], fill=(238, 190, 153))
    # papillon
    d.polygon(P([(850, 520), (878, 508), (878, 532)]), fill=(240, 65, 67))
    d.polygon(P([(850, 520), (822, 508), (822, 532)]), fill=(240, 65, 67))
    d.polygon(P([(850, 506), (866, 520), (850, 534), (834, 520)]), fill=(240, 65, 67))
    # capelli (chignon)
    E(836, 276, 874, 306, fill=(57, 44, 39))
    # testa
    E(762, 292, 938, 484, fill=(246, 209, 178))
    # capelli sopra
    d.pieslice(P([(758, 286), (942, 408)])[0] + P([(758, 286), (942, 408)])[1], 180, 360, fill=(57, 44, 39))
    E(786, 336, 914, 372, fill=(246, 209, 178))
    # guance
    ch = Image.new("RGBA", im.size, (0, 0, 0, 0)); cd = ImageDraw.Draw(ch)
    for cx in (783, 917):
        a = P([(cx - 20, 412), (cx + 20, 434)]); cd.ellipse(a[0] + a[1], fill=(245, 150, 150, 140))
    im.alpha_composite(ch); d = ImageDraw.Draw(im)
    # occhiali
    for cx in (815, 885):
        E(cx - 33, 366, cx + 33, 432, outline=(29, 38, 60), width=7 * SS)
    d.line(P([(848, 398), (852, 398)]), fill=(29, 38, 60), width=6 * SS)
    for cx in (815, 885):
        if blink:
            d.line(P([(cx - 12, 400), (cx + 12, 400)]), fill=(29, 38, 60), width=5 * SS)
        else:
            E(cx - 9, 389, cx + 9, 407, fill=(35, 36, 48))
            E(cx - 4, 391, cx + 2, 397, fill=(255, 255, 255))
    # bocca
    mx, my = 850, 442
    if mouth:
        if expr == "surprised":
            E(mx - 17, my - 10, mx + 17, my + 24, fill=(115, 41, 39))
        else:
            E(mx - 20, my - 8, mx + 20, my + 16, fill=(115, 41, 39))
    else:
        if expr == "serious":
            d.line(P([(mx - 18, my + 4), (mx + 18, my + 4)]), fill=(115, 41, 39), width=5 * SS)
        else:
            d.arc(P([(mx - 32, my - 20), (mx + 32, my + 14)])[0] + P([(mx - 32, my - 20), (mx + 32, my + 14)])[1], 20, 160, fill=(115, 41, 39), width=6 * SS)
    return im.resize((w, h), Image.LANCZOS)

# ---------------------------------------------------------------- utilità disegno
def shadow_text(base, xy, text, fnt, fill, stroke=7, anchor="ls"):
    """Sottotitolo stile reference: testo con contorno scuro e ombra morbida."""
    d = ImageDraw.Draw(base)
    x, y = xy
    d.text((x + 3, y + 5), text, font=fnt, fill=(6, 8, 26), stroke_width=stroke, stroke_fill=(6, 8, 26), anchor=anchor)
    d.text((x, y), text, font=fnt, fill=fill, stroke_width=stroke, stroke_fill=(16, 16, 40), anchor=anchor)

def rounded_card(size, fill=CARD, border=YEL_D, bw=5, r=48):
    w, h = size
    im = Image.new("RGBA", (w * 2, h * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, w * 2 - 1, h * 2 - 1], radius=r * 2, fill=fill + (255,), outline=border + (255,), width=bw * 2)
    return im.resize((w, h), Image.LANCZOS)

def pill(text, fnt=None, color=YEL, pad=(34, 14), fill=(44, 52, 92)):
    fnt = fnt or font(F_FRED6, 34)
    tmp = ImageDraw.Draw(Image.new("RGB", (4, 4)))
    tw = tmp.textlength(text, font=fnt)
    w, h = int(tw + pad[0] * 2), int(fnt.size + pad[1] * 2 + 6)
    im = rounded_card((w, h), fill=fill, border=color, bw=3, r=h // 2)
    d = ImageDraw.Draw(im)
    d.text((w / 2, h / 2 + 2), text, font=fnt, fill=color, anchor="mm")
    return im

# icone semplici disegnate a mano
def icon_coin(size=84, color=YEL):
    im = Image.new("RGBA", (size * 3, size * 3), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.ellipse([6, 6, size * 3 - 6, size * 3 - 6], fill=color + (255,), outline=(200, 150, 20, 255), width=9)
    d.text((size * 1.5, size * 1.55), "€", font=font(F_MONT9, int(size * 1.7)), fill=(150, 100, 10), anchor="mm")
    return im.resize((size, size), Image.LANCZOS)

def icon_cart(size=84, color=(120, 190, 255)):
    im = Image.new("RGBA", (size * 3, size * 3), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    s = size * 3
    d.line([(s * .08, s * .18), (s * .22, s * .18), (s * .32, s * .62), (s * .8, s * .62), (s * .9, s * .30), (s * .26, s * .30)], fill=color + (255,), width=int(s * .08), joint="curve")
    for cx in (s * .38, s * .74):
        d.ellipse([cx - s * .07, s * .74, cx + s * .07, s * .88], fill=color + (255,))
    return im.resize((size, size), Image.LANCZOS)

def icon_down(size=84, color=RED):
    im = Image.new("RGBA", (size * 3, size * 3), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    s = size * 3
    d.line([(s * .12, s * .22), (s * .42, s * .52), (s * .58, s * .38), (s * .88, s * .72)], fill=color + (255,), width=int(s * .1), joint="curve")
    d.polygon([(s * .90, s * .86), (s * .94, s * .54), (s * .66, s * .72)], fill=color + (255,))
    return im.resize((size, size), Image.LANCZOS)

def icon_bank(size=84, color=YEL):
    im = Image.new("RGBA", (size * 3, size * 3), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    s = size * 3
    d.polygon([(s * .5, s * .08), (s * .94, s * .32), (s * .06, s * .32)], fill=color + (255,))
    for x in (.16, .42, .68):
        d.rectangle([s * x, s * .38, s * (x + .16), s * .74], fill=color + (255,))
    d.rectangle([s * .06, s * .8, s * .94, s * .9], fill=color + (255,))
    return im.resize((size, size), Image.LANCZOS)

ICONS = {"coin": icon_coin, "cart": icon_cart, "down": icon_down, "bank": icon_bank}


@functools.lru_cache(None)
def glow_sprite(kind):
    """Alone dietro a chi parla: lupo = disco scuro uniforme, narratore = disco con centro più chiaro."""
    r = 190
    im = Image.new("RGBA", (r * 2, r * 2), (0, 0, 0, 0))
    px = im.load()
    for y in range(r * 2):
        for x in range(r * 2):
            dd = math.hypot(x - r + .5, y - r + .5) / r
            if dd > 1: continue
            edge = clamp((1 - dd) * 40)
            if kind == "wolf":
                c = (37, 42, 57); a = 255
            else:
                t = dd
                c = (int(lerp(72, 43, t)), int(lerp(68, 44, t)), int(lerp(76, 58, t))); a = 255
            px[x, y] = c + (int(a * min(1.0, edge)),)
    return im.filter(ImageFilter.GaussianBlur(1.2))


def circle_sprite(w, h, color):
    S = 2
    im = Image.new("RGBA", (w * S, h * S), (0, 0, 0, 0))
    ImageDraw.Draw(im).ellipse([0, 0, w * S - 1, h * S - 1], fill=color)
    return im.resize((w, h), Image.LANCZOS)

def make_layers():
    """Sfondo a livelli: gradiente fisso, cerchi che si muovono piano, intestazione e nomi sopra."""
    top, bot = (10, 17, 47), (26, 41, 90)
    base = Image.new("RGB", (W, H)); px = ImageDraw.Draw(base)
    for y in range(H):
        t = y / (H - 1)
        px.line([(0, y), (W, y)], fill=tuple(int(lerp(top[i], bot[i], t)) for i in range(3)))
    over = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d2 = ImageDraw.Draw(over)
    hf = font(F_FRED7, 46); txt = "Pillole di Economia"
    w = d2.textlength(txt, font=hf)
    d2.text(((W - w) / 2, 70), txt, font=hf, fill=YEL + (255,))
    d2.rounded_rectangle([450, 143, 630, 150], radius=4, fill=YEL + (255,))
    lf = font(F_FRED6, 34)
    for cx, name in ((230, "Il Lupo"), (850, "La Narratrice")):
        w = d2.textlength(name, font=lf)
        d2.text((cx - w / 2, 628), name, font=lf, fill=(235, 240, 252, 255))
    c1 = circle_sprite(500, 560, (24, 40, 86, 200))     # alto a destra
    c2 = circle_sprite(760, 760, (58, 46, 98, 150))     # basso a sinistra
    return base, over, c1, c2


# =================================================================== PERSONAGGI v4 (più dettagliati, ombreggiati)
from PIL import ImageFilter, ImageChops
import numpy as np
import math as _m

def _el(d, x0, y0, x1, y1, **kw): d.ellipse([x0 * SS, y0 * SS, x1 * SS, y1 * SS], **kw)
def _poly(d, pts, **kw): d.polygon([(x * SS, y * SS) for x, y in pts], **kw)
def _ln(d, pts, w, **kw): d.line([(x * SS, y * SS) for x, y in pts], width=max(1, int(w * SS)), **kw)
def _arc(d, x0, y0, x1, y1, a0, a1, w, **kw): d.arc([x0 * SS, y0 * SS, x1 * SS, y1 * SS], a0, a1, width=max(1, int(w * SS)), **kw)
def _nm(size): return Image.new("L", size, 0)
def _round(m, r): return m.filter(ImageFilter.GaussianBlur(r * SS)).point(lambda v: 255 if v > 127 else 0)

def _vg(size, y0, y1, c0, c1):
    Wd, Hd = size
    ys = np.clip((np.arange(Hd) - y0 * SS) / max(1.0, (y1 - y0) * SS), 0, 1)[:, None]
    a0 = np.array(c0[:3], float); a1 = np.array(c1[:3], float)
    arr = a0[None, :] * (1 - ys) + a1[None, :] * ys
    arr = np.repeat(arr[:, None, :], Wd, axis=1).astype(np.uint8)
    return Image.fromarray(arr, "RGB").convert("RGBA")

def _fill(im, mask, c0, c1=None, y0=0, y1=1, outline=None, ow=0):
    if outline and ow:
        g = mask.filter(ImageFilter.GaussianBlur(ow * SS * 0.6)).point(lambda v: 255 if v > 6 else 0)
        o = Image.new("RGBA", im.size, tuple(outline) + (255,)); o.putalpha(g); im.alpha_composite(o)
    lay = _vg(im.size, y0, y1, c0, c1) if c1 else Image.new("RGBA", im.size, tuple(c0) + (255,))
    lay.putalpha(mask); im.alpha_composite(lay)

def _shade(im, mask, box, color, blur, alpha):
    m = _nm(im.size); ImageDraw.Draw(m).ellipse([b * SS for b in box], fill=int(alpha))
    m = ImageChops.multiply(m.filter(ImageFilter.GaussianBlur(blur * SS)), mask)
    lay = Image.new("RGBA", im.size, tuple(color) + (255,)); lay.putalpha(m); im.alpha_composite(lay)

def _stroke(d, a, b, th, col):
    _ln(d, [a, b], th, fill=col)
    for q in (a, b):
        r = th / 2; _el(d, q[0] - r, q[1] - r, q[0] + r, q[1] + r, fill=col)

# ---------------------------------------------------------------- lupo
@functools.lru_cache(None)
def _wolf_base():
    w, h = 440, 420; size = (w * SS, h * SS); im = Image.new("RGBA", size, (0, 0, 0, 0))
    OL = (66, 72, 98)
    # collo/pelliccia
    m = _nm(size); d = ImageDraw.Draw(m); _el(d, 84, 316, 356, 480, fill=255)
    for k in range(8):
        x = 100 + k * 34; _poly(d, [(x - 18, 340), (x + 18, 340), (x, 392)], fill=255)
    m = _round(m, 3); _fill(im, m, (238, 242, 248), (188, 197, 219), 316, 420, OL, 3.5)
    # orecchie
    for sg in (0, 1):
        X = (lambda x: x) if sg == 0 else (lambda x: 440 - x)
        m = _nm(size); d = ImageDraw.Draw(m)
        _poly(d, [(X(92), 176), (X(74), 12), (X(214), 98)], fill=255); m = _round(m, 8)
        _fill(im, m, (176, 184, 206), (138, 146, 170), 12, 176, OL, 3.5)
        mi = _nm(size); d = ImageDraw.Draw(mi)
        _poly(d, [(X(108), 154), (X(96), 48), (X(190), 104)], fill=255); mi = _round(mi, 6)
        _fill(im, mi, (255, 206, 218), (230, 146, 174), 48, 154)
        _shade(im, mi, (X(100) - 30, 40, X(100) + 40, 100), (200, 110, 140), 10, 110)
    # testa
    m = _nm(size); d = ImageDraw.Draw(m); _el(d, 56, 76, 384, 378, fill=255)
    for sg in (0, 1):
        X = (lambda x: x) if sg == 0 else (lambda x: 440 - x)
        _poly(d, [(X(80), 244), (X(22), 290), (X(72), 302), (X(26), 342), (X(100), 332)], fill=255)
    head = _round(m, 5)
    _fill(im, head, (188, 196, 216), (136, 144, 168), 76, 378, OL, 3.5)
    _shade(im, head, (110, 56, 330, 176), (104, 112, 138), 24, 120)     # cappuccio scuro sulla fronte
    _shade(im, head, (150, 80, 230, 120), (210, 216, 232), 12, 90)
    _shade(im, head, (60, 330, 380, 440), (92, 100, 126), 22, 100)
    # muso e guance chiare
    mm = _nm(size); d = ImageDraw.Draw(mm)
    _el(d, 124, 232, 316, 392, fill=255); _el(d, 76, 240, 198, 346, fill=255); _el(d, 242, 240, 364, 346, fill=255)
    mm = ImageChops.multiply(_round(mm, 12), head)
    _fill(im, mm, (251, 252, 255), (214, 221, 235), 232, 392)
    _shade(im, mm, (150, 340, 290, 420), (170, 180, 202), 14, 90)
    return im

def _eye_layer(size, cx, ey, expr, blink):
    """Occhio grande, iride ambra, riflessi; ritorna layer RGBA ritagliato sull'ovale dell'occhio."""
    sx, sy = (30, 34) if expr != "surprised" else (33, 38)
    E = Image.new("RGBA", size, (0, 0, 0, 0)); d = ImageDraw.Draw(E)
    _el(d, cx - sx, ey - sy, cx + sx, ey + sy, fill=(255, 255, 255, 255))
    _shade(E, _eye_mask(size, cx, ey, sx, sy), (cx - sx, ey - sy - 14, cx + sx, ey - sy + 24), (150, 156, 180), 6, 150)
    d = ImageDraw.Draw(E)
    ox_, oy_ = (7, 7) if expr == "skeptic" else (0, 3)
    ir = 21 if expr != "surprised" else 18
    ix, iy = cx + ox_, ey + oy_
    _el(d, ix - ir, iy - ir, ix + ir, iy + ir, fill=(186, 110, 26, 255))
    _el(d, ix - ir + 4, iy - ir + 5, ix + ir - 4, iy + ir - 2, fill=(236, 170, 62, 255))
    pr = 11 if expr != "surprised" else 7
    _el(d, ix - pr, iy - pr, ix + pr, iy + pr, fill=(24, 24, 36, 255))
    _el(d, ix - 10, iy - 14, ix + 2, iy - 3, fill=(255, 255, 255, 255))
    _el(d, ix + 5, iy + 3, ix + 12, iy + 10, fill=(255, 255, 255, 230))
    if expr == "skeptic":                              # palpebra pesante
        d.rectangle([(cx - sx - 4) * SS, (ey - sy - 4) * SS, (cx + sx + 4) * SS, (ey - 4) * SS], fill=(158, 166, 190, 255))
        _ln(d, [(cx - sx, ey - 4), (cx + sx, ey - 4)], 5, fill=(52, 56, 78, 255))
    a = ImageChops.multiply(E.getchannel("A"), _eye_mask(size, cx, ey, sx, sy)); E.putalpha(a)
    d = ImageDraw.Draw(E)
    _el(d, cx - sx, ey - sy, cx + sx, ey + sy, outline=(52, 56, 78, 255), width=3 * SS)
    _arc(d, cx - sx - 2, ey - sy - 2, cx + sx + 2, ey + sy + 2, 205, 335, 6, fill=(44, 48, 68, 255))
    return E

def _eye_mask(size, cx, ey, sx, sy):
    m = _nm(size); _el(ImageDraw.Draw(m), cx - sx, ey - sy, cx + sx, ey + sy, fill=255); return m

@functools.lru_cache(None)
def wolf(expr="neutral", mouth=0, blink=False):
    """expr: neutral | skeptic | surprised | happy | worried. Sprite 440x420."""
    w, h = 440, 420; size = (w * SS, h * SS)
    im = _wolf_base().copy(); d = ImageDraw.Draw(im)
    DK = (44, 44, 60); BR = (70, 76, 102)
    ex, ey = (158, 282), 208
    # guance rosa
    ch = Image.new("RGBA", size, (0, 0, 0, 0)); cd = ImageDraw.Draw(ch)
    for cx in (110, 330): _el(cd, cx - 30, 284, cx + 30, 316, fill=(255, 140, 168, 255))
    ch = ch.filter(ImageFilter.GaussianBlur(8 * SS)); ch.putalpha(ch.getchannel("A").point(lambda v: int(v * 0.55))); im.alpha_composite(ch); d = ImageDraw.Draw(im)
    # occhi
    for cx in ex:
        if blink:
            _arc(d, cx - 28, ey - 16, cx + 28, ey + 14, 25, 155, 7, fill=DK)
        else:
            im.alpha_composite(_eye_layer(size, cx, ey, expr, blink)); d = ImageDraw.Draw(im)
    # sopracciglia
    def brow(cx, tilt, y, L=56, th=12):
        _stroke(d, (cx - L / 2, y + tilt), (cx + L / 2, y - tilt), th, BR)
    if blink: brow(ex[0], 0, 160); brow(ex[1], 0, 160)
    elif expr == "skeptic": brow(ex[0], 3, 166); brow(ex[1], -11, 154)
    elif expr == "surprised": brow(ex[0], 4, 148); brow(ex[1], -4, 148)
    elif expr == "worried": brow(ex[0], 10, 158); brow(ex[1], -10, 158)
    elif expr == "happy": brow(ex[0], -3, 158); brow(ex[1], 3, 158)
    else: brow(ex[0], 0, 160); brow(ex[1], 0, 160)
    # naso
    m = _nm(size); dm = ImageDraw.Draw(m); _poly(dm, [(184, 266), (256, 266), (220, 304)], fill=255); m = _round(m, 7)
    _fill(im, m, (62, 64, 82), (28, 28, 40), 266, 304)
    _shade(im, m, (196, 266, 226, 282), (190, 196, 214), 5, 190); d = ImageDraw.Draw(im)
    _ln(d, [(220, 304), (220, 318)], 3.5, fill=DK)
    # baffi (puntini)
    for sx_ in (-1, 1):
        for (px_, py_) in ((158, 300), (172, 314), (150, 316)):
            xx = 220 + sx_ * (220 - px_); _el(d, xx - 3, py_ - 3, xx + 3, py_ + 3, fill=(120, 128, 150))
    # bocca
    MY = 330
    if mouth:
        if expr == "surprised":
            _el(d, 196, 318, 244, 366, fill=(110, 36, 56))
            _el(d, 204, 342, 236, 362, fill=(240, 130, 156))
        else:
            mk = _nm(size); dm = ImageDraw.Draw(mk); _el(dm, 182, 316, 258, 372, fill=255)
            dm.rectangle([0, 0, size[0], 316 * SS + 20], fill=0)
            lay = Image.new("RGBA", size, (110, 36, 56, 255)); lay.putalpha(mk); im.alpha_composite(lay)
            tg = _nm(size); dt = ImageDraw.Draw(tg); _el(dt, 200, 346, 240, 384, fill=255); tg = ImageChops.multiply(tg, mk)
            lay = Image.new("RGBA", size, (240, 130, 156, 255)); lay.putalpha(tg); im.alpha_composite(lay); d = ImageDraw.Draw(im)
            _poly(d, [(190, 318), (204, 318), (197, 336)], fill=(255, 255, 255)); _poly(d, [(236, 318), (250, 318), (243, 336)], fill=(255, 255, 255))
            _ln(d, [(182, 318), (258, 318)], 4.5, fill=DK)
    else:
        if expr in ("skeptic", "worried"):
            _arc(d, 186, 326, 254, 362, 205, 335, 6, fill=(92, 40, 56))
        elif expr == "happy":
            _arc(d, 172, 312, 268, 356, 20, 160, 6.5, fill=(92, 40, 56))
        else:
            _arc(d, 184, 312, 222, 340, 0, 120, 5.5, fill=(92, 40, 56)); _arc(d, 218, 312, 256, 340, 60, 180, 5.5, fill=(92, 40, 56))
    return im.resize((w, h), Image.LANCZOS)

# ---------------------------------------------------------------- narratore
@functools.lru_cache(None)
def _narr_base():
    w, h = 360, 380; size = (w * SS, h * SS); im = Image.new("RGBA", size, (0, 0, 0, 0))
    SK0, SK1, SKD = (252, 222, 192), (236, 188, 150), (214, 160, 124)
    # capelli lunghi dietro le spalle
    bk = _nm(size); d = ImageDraw.Draw(bk)
    _el(d, 76, 30, 284, 250, fill=255)
    _poly(d, [(84, 120), (276, 120), (290, 290), (70, 290)], fill=255)
    bk = _round(bk, 10)
    _fill(im, bk, (96, 66, 50), (52, 36, 30), 30, 300, (34, 24, 22), 3)
    # collo
    m = _nm(size); d = ImageDraw.Draw(m); _poly(d, [(148, 205), (212, 205), (218, 300), (142, 300)], fill=255); m = _round(m, 4)
    _fill(im, m, (232, 184, 146), (214, 160, 124), 205, 300)
    _shade(im, m, (130, 196, 230, 252), (150, 96, 72), 12, 130)
    # giacca
    m = _nm(size); d = ImageDraw.Draw(m); _el(d, 12, 256, 348, 620, fill=255); m = _round(m, 4)
    _fill(im, m, (84, 154, 255), (40, 100, 212), 256, 380, (24, 56, 124), 4)
    _shade(im, m, (24, 262, 140, 330), (150, 200, 255), 14, 110)
    # camicia
    m = _nm(size); d = ImageDraw.Draw(m); _poly(d, [(146, 258), (214, 258), (238, 390), (122, 390)], fill=255); m = _round(m, 2)
    _fill(im, m, (255, 255, 255), (222, 229, 243), 258, 380)
    # baveri
    for sg in (0, 1):
        X = (lambda x: x) if sg == 0 else (lambda x: 360 - x)
        mm = _nm(size); d = ImageDraw.Draw(mm); _poly(d, [(X(144), 254), (X(184), 340), (X(140), 392), (X(94), 392), (X(100), 292)], fill=255); mm = _round(mm, 3)
        _fill(im, mm, (46, 108, 224), (32, 84, 190), 254, 392, (24, 56, 124), 3)
    # foulard
    d = ImageDraw.Draw(im)
    _poly(d, [(180, 290), (160, 346), (188, 336)], fill=(232, 52, 62), outline=(150, 24, 36), width=3 * SS)
    _poly(d, [(180, 290), (206, 342), (186, 336)], fill=(246, 74, 82), outline=(150, 24, 36), width=3 * SS)
    _el(d, 166, 274, 194, 302, fill=(246, 74, 82), outline=(150, 24, 36), width=3 * SS)
    # orecchie
    for x0 in (82, 248):
        m = _nm(size); d = ImageDraw.Draw(m); _el(d, x0, 126, x0 + 30, 182, fill=255)
        _fill(im, m, SK0, SK1, 126, 182, (190, 136, 106), 3)
        _shade(im, m, (x0 + 6, 142, x0 + 24, 168), (226, 150, 130), 4, 160)
        d = ImageDraw.Draw(im); _el(d, x0 + 8, 176, x0 + 22, 190, fill=(255, 210, 90), outline=(190, 140, 30), width=2 * SS)
    # testa
    m = _nm(size); d = ImageDraw.Draw(m); _el(d, 96, 38, 264, 206, fill=255); _el(d, 112, 120, 248, 238, fill=255); head = _round(m, 8)
    _fill(im, head, SK0, SK1, 38, 238, (196, 142, 110), 3.5)
    _shade(im, head, (110, 190, 250, 270), (176, 118, 88), 14, 100)
    _shade(im, head, (118, 70, 190, 130), (255, 244, 230), 16, 90)
    # guance
    ch = Image.new("RGBA", size, (0, 0, 0, 0)); cd = ImageDraw.Draw(ch)
    for cx in (124, 236): _el(cd, cx - 22, 170, cx + 22, 198, fill=(255, 130, 130, 255))
    ch = ch.filter(ImageFilter.GaussianBlur(7 * SS)); ch.putalpha(ch.getchannel("A").point(lambda v: int(v * 0.55))); im.alpha_composite(ch)
    # naso
    d = ImageDraw.Draw(im)
    nm_ = _nm(size); _el(ImageDraw.Draw(nm_), 170, 148, 190, 176, fill=255)
    _fill(im, nm_, (238, 190, 156), (222, 168, 132), 148, 176)
    _shade(im, nm_, (174, 150, 186, 160), (255, 236, 220), 3, 170)
    # capelli
    hm = _nm(size); d = ImageDraw.Draw(hm)
    pts = [(180 + 94 * _m.cos(_m.radians(a)), 94 + 70 * _m.sin(_m.radians(a))) for a in range(180, 361, 6)]
    pts += [(274, 214), (258, 222), (256, 150), (236, 108), (196, 86), (150, 90), (112, 116), (104, 150), (102, 222), (86, 214)]
    _poly(d, pts, fill=255)
    hm = _round(hm, 3)
    _fill(im, hm, (112, 80, 60), (58, 42, 34), 12, 144, (34, 24, 22), 3)
    _shade(im, hm, (130, 30, 214, 60), (176, 140, 112), 7, 170)
    d = ImageDraw.Draw(im)
    for k in range(4): _arc(d, 136 + k * 16, 36 + k * 3, 216 + k * 16, 90 + k * 3, 200, 280, 2.5, fill=(78, 56, 44))
    # taglio sotto il petto (base busto)
    a = im.getchannel("A"); cut = Image.new("L", size, 255); ImageDraw.Draw(cut).rectangle([0, 366 * SS, size[0], size[1]], fill=0)
    im.putalpha(ImageChops.multiply(a, cut))
    return im

@functools.lru_cache(None)
def narrator(expr="smile", mouth=0, blink=False):
    """expr: smile | surprised | serious. Sprite 360x380."""
    w, h = 360, 380; size = (w * SS, h * SS)
    im = _narr_base().copy(); d = ImageDraw.Draw(im)
    LC, EY = (148, 212), 140
    DK = (36, 40, 62)
    # occhi dietro gli occhiali
    for cx in LC:
        if blink:
            _arc(d, cx - 14, EY - 8, cx + 14, EY + 8, 20, 160, 3.5, fill=DK)
        else:
            sy = 11 if expr != "surprised" else 14
            E = Image.new("RGBA", size, (0, 0, 0, 0)); de = ImageDraw.Draw(E)
            _el(de, cx - 15, EY - sy, cx + 15, EY + sy, fill=(255, 255, 255, 255))
            _el(de, cx - 9, EY - 9 + 1, cx + 9, EY + 9 + 1, fill=(98, 62, 36, 255))
            _el(de, cx - 6, EY - 6 + 1, cx + 6, EY + 6 + 1, fill=(24, 20, 28, 255))
            _el(de, cx - 5, EY - 8, cx + 0, EY - 3, fill=(255, 255, 255, 255))
            mk = _nm(size); _el(ImageDraw.Draw(mk), cx - 15, EY - sy, cx + 15, EY + sy, fill=255)
            E.putalpha(ImageChops.multiply(E.getchannel("A"), mk)); im.alpha_composite(E); d = ImageDraw.Draw(im)
            _arc(d, cx - 16, EY - sy - 2, cx + 16, EY + sy + 2, 200, 340, 3.5, fill=DK)
            sg_ = -1 if cx < 180 else 1
            _ln(d, [(cx + sg_ * 14, EY - 7), (cx + sg_ * 22, EY - 13)], 3, fill=DK); _ln(d, [(cx + sg_ * 15, EY - 3), (cx + sg_ * 24, EY - 5)], 2.6, fill=DK)
    # lenti + montatura
    gl = Image.new("RGBA", size, (0, 0, 0, 0)); dg = ImageDraw.Draw(gl)
    for cx in LC:
        _el(dg, cx - 30, EY - 28, cx + 30, EY + 28, fill=(190, 225, 255, 38))
        _poly(dg, [(cx - 22, EY - 16), (cx - 8, EY - 22), (cx - 18, EY - 4)], fill=(255, 255, 255, 120))
    im.alpha_composite(gl); d = ImageDraw.Draw(im)
    for cx in LC: _el(d, cx - 30, EY - 28, cx + 30, EY + 28, outline=(38, 42, 66), width=5 * SS)
    _ln(d, [(178, EY - 6), (182, EY - 6)], 4.5, fill=(38, 42, 66))
    _ln(d, [(118, EY - 8), (98, EY - 6)], 4, fill=(38, 42, 66)); _ln(d, [(242, EY - 8), (262, EY - 6)], 4, fill=(38, 42, 66))
    # sopracciglia
    BRC = (72, 50, 40)
    def brow(cx, tilt, y, L=40, th=6): _stroke(d, (cx - L / 2, y + tilt), (cx + L / 2, y - tilt), th, BRC)
    if expr == "surprised": brow(LC[0], 4, 96); brow(LC[1], -4, 96)
    elif expr == "serious": brow(LC[0], -4, 104); brow(LC[1], 4, 104)
    else: brow(LC[0], 2, 102); brow(LC[1], -2, 102)
    # bocca
    mx, my = 180, 196; LIP = (206, 62, 88)
    if mouth:
        if expr == "surprised":
            _el(d, mx - 14, my - 10, mx + 14, my + 22, fill=(112, 34, 40))
            _el(d, mx - 8, my + 6, mx + 8, my + 20, fill=(226, 110, 120))
        else:
            mk = _nm(size); dm = ImageDraw.Draw(mk); _poly(dm, [(mx - 26, my - 8), (mx + 26, my - 8), (mx + 20, my + 6), (mx + 8, my + 18), (mx - 8, my + 18), (mx - 20, my + 6)], fill=255); mk = _round(mk, 3)
            lay = Image.new("RGBA", size, (112, 34, 40, 255)); lay.putalpha(mk); im.alpha_composite(lay)
            tk = _nm(size); _el(ImageDraw.Draw(tk), mx - 14, my + 6, mx + 14, my + 26, fill=255); tk = ImageChops.multiply(tk, mk)
            lay = Image.new("RGBA", size, (226, 110, 120, 255)); lay.putalpha(tk); im.alpha_composite(lay)
            tt = _nm(size); ImageDraw.Draw(tt).rectangle([(mx - 24) * SS, (my - 8) * SS, (mx + 24) * SS, (my) * SS], fill=255); tt = ImageChops.multiply(tt, mk)
            lay = Image.new("RGBA", size, (255, 255, 255, 255)); lay.putalpha(tt); im.alpha_composite(lay); d = ImageDraw.Draw(im)
            _ln(d, [(mx - 26, my - 8), (mx + 26, my - 8)], 2.5, fill=LIP)
    else:
        if expr == "serious": _ln(d, [(mx - 18, my + 4), (mx + 18, my + 4)], 6.5, fill=LIP)
        else: _arc(d, mx - 30, my - 20, mx + 30, my + 14, 25, 155, 7, fill=LIP)
    return im.resize((w, h), Image.LANCZOS)


# =================================================================== PERSONAGGI 3D (sprite renderizzati con three.js)
import os as _os
if _os.environ.get("LUPO3D", "1") != "0":
    _SP = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "sprites3d")
    @functools.lru_cache(None)
    def wolf(expr="neutral", mouth=0, blink=False):
        return Image.open(_os.path.join(_SP, f"wolf_{expr}_{int(bool(mouth))}_{int(bool(blink))}.png")).convert("RGBA")
    @functools.lru_cache(None)
    def narrator(expr="smile", mouth=0, blink=False):
        return Image.open(_os.path.join(_SP, f"narr_{expr}_{int(bool(mouth))}_{int(bool(blink))}.png")).convert("RGBA")
