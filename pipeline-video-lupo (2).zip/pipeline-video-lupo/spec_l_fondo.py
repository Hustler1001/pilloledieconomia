# Fondo di emergenza 1/2 - esempio calcolato (regola pratica, non obbligo ne' consulenza)
SPESE=1600; VERSO=250
assert 3*SPESE==4800 and 6*SPESE==9600
assert round(3*SPESE/VERSO,1)==19.2 and round(6*SPESE/VERSO,1)==38.4
import math
assert math.ceil(SPESE/VERSO)==7
TTS="tts_l_fondo"; OUT="pillole_fondo_emergenza_1di2.mp4"; FRAMES=""; PART=None; MARK=(1,3,7)
FONTI="Esempio calcolato · regola pratica, non consulenza"
RATE_TTS="+8%"
def N(t): return dict(who="narr",wolf="x",narr="x",text=t)
def W(t): return dict(who="wolf",wolf="x",narr="x",text=t)
LINES=[
 N("Parte ^1_su_2|uno_su_due. Quanti_soldi_tengo_da_parte per_le_emergenze?"),
 W("Regola_pratica: da ^3|tre a ^6|sei mesi di spese essenziali. Non è un obbligo."),
 N("Se spendo ^1.600|milleseicento_euro al mese?"),
 W("Tre_mesi: ^4.800|quattromilaottocento_euro. Sei mesi: ^9.600|novemilaseicento."),
 N("Mamma mia! E se metto da parte ^250|duecentocinquanta_euro al mese?"),
 W("Per i tre mesi, circa ^19|diciannove mesi. Per i sei, circa ^38|trentotto."),
 N("Più di tre anni?"),
 W("Parti piccola: un mese di spese, ^1.600|milleseicento_euro. In ^7|sette mesi ci sei."),
 N("E poi dove li tengo? Lo so, prossima puntata!"),
 N("Scrivi nei commenti la parola ^BUDGET|badget e ti mando il foglio ^gratis."),
]
CARDS=[
 dict(at=0,kind="big",tag="EMERGENZE",pill="Parte 1/2",big="3-6 mesi",label="di spese essenziali",label2="regola pratica, non obbligo",col="y"),
 dict(at=3,kind="compare",tag="SPESE 1.600 €",pill="Parte 1/2",sides=[dict(head="3 MESI",big="4.800 €",sub="1.600 € × 3",col="y"),dict(head="6 MESI",big="9.600 €",sub="1.600 € × 6",col="g")],foot="Esempio calcolato"),
 dict(at=5,kind="bars",tag="TEMPO NECESSARIO",pill="Parte 1/2",bars=[dict(h=0.5,val="19 mesi",name="3 MESI",col="y"),dict(h=1.0,val="38 mesi",name="6 MESI",col="g")],foot="mettendo da parte 250 € al mese"),
 dict(at=7,kind="big",tag="PRIMO PASSO",pill="Parte 1/2",big="1.600 €",label="un mese di spese",label2="7 mesi da 250 € e ci sei",col="g"),
 dict(at=9,kind="END"),
]
