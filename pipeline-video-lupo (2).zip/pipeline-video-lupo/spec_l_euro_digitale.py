# Complotto del giorno: "con l'euro digitale la BCE vedrà ogni tuo acquisto" - teoria solo da verificare
# Numeri e fatti da fonti: BCE FAQ euro digitale (agg. 17/08/2026): Eurosistema non puo' collegare le operazioni a persone; offline privacy simile al contante;
# affianca, non sostituisce, il contante; pilota dalla seconda meta' del 2027. PE commissione Econ 23/06/2026 (via Adnkronos): contante resta, vietati i cartelli "no cash".
PILOTA=2027
TTS="tts_l_eurodig"; OUT="pillole_complotto_euro_digitale.mp4"; FRAMES=""; PART=None; MARK=(1,3,7)
FONTI="Fonti: BCE (FAQ euro digitale, 17/08/2026)"
RATE_TTS="+8%"
def N(t): return dict(who="narr",wolf="x",narr="x",text=t)
def W(t): return dict(who="wolf",wolf="x",narr="x",text=t)
LINES=[
 N("Complotto_del_giorno: con_l'^euro_digitale|euro_digitale la ^BCE|bce vede ogni_mio_acquisto. È ^vero?"),
 W("Capisco_il_dubbio. Ma per la ^BCE|bce, no: non può collegare i pagamenti a una persona."),
 N("E la mia banca li vede?"),
 W("Sì, come oggi con la carta: online ti identifica per l'~antiriciclaggio. Offline, privacy ^simile|simile_al_contante."),
 N("Quindi il contante sparisce?"),
 W("No. L'euro digitale lo ^affianca|affianca, non lo sostituisce. Il pilota parte nel ^2027|duemilaventisette."),
 N("Allora è tutto falso?"),
 W("Né vero né falso: ~manca_il_contesto. La ^BCE|bce non sa chi sei, la banca sì."),
 N("Meglio controllare, prima di condividere!"),
 N("Scrivi nei commenti la parola ^BUDGET|badget e ti mando il foglio ^gratis."),
]
CARDS=[
 dict(at=0,kind="big",tag="COMPLOTTO",pill="vero o falso?",big="BCE vede tutto?",label="La teoria sull'euro digitale",label2="da verificare, non da credere",col="y"),
 dict(at=1,kind="compare",tag="CHI VEDE",pill="online",sides=[dict(head="BCE",big="NO",sub="non lega i pagamenti a una persona",col="g"),dict(head="BANCA",big="SÌ",sub="ti identifica, come con la carta",col="y")],foot="Offline: privacy simile al contante"),
 dict(at=5,kind="big",tag="CONTANTE",pill="resta",big="RESTA",label="L'euro digitale lo affianca",label2="Pilota: 2° semestre 2027",col="g"),
 dict(at=7,kind="stamp",tag="VERDETTO",pill="verificato",doc="EURO DIGITALE",big="BCE vede tutto?",label="la BCE no, la banca sì",stamp="MANCA IL CONTESTO"),
 dict(at=9,kind="END"),
]
