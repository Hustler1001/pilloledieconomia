# Rate e prestiti 2/2 - come leggere un contratto di finanziamento (esempio calcolato)
P=10000; N=36; I=0.08/12; ISTR=200; INC=2
RATA=P*I/(1-(1+I)**-N)
assert round(RATA,2)==313.36
TOT=RATA*N+ISTR+INC*N
assert round(TOT)==11553 and round(TOT-P)==1553 and round(RATA+INC)==315
cf=[P-ISTR]+[-(RATA+INC)]*N
f=lambda x: sum(c/(1+x)**k for k,c in enumerate(cf))
lo,hi=0,0.1
for _ in range(100):
    m=(lo+hi)/2
    if f(m)>0: hi=m
    else: lo=m
TAEG=((1+lo)**12-1)*100
assert round(TAEG,2)==10.27
TTS="tts_l_prestito"; OUT="pillole_prestito_taeg_2di2.mp4"; FRAMES=""; PART=None; MARK=(1,3,7)
FONTI="Fonti: Banca d'Italia (TAEG) · esempio calcolato"
RATE_TTS="+8%"
def N_(t): return dict(who="narr",wolf="x",narr="x",text=t)
def W_(t): return dict(who="wolf",wolf="x",narr="x",text=t)
LINES=[
 N_("Parte ^2_su_2|due_su_due. Prestito_da ^10.000|diecimila_euro, tasso ^8%|otto_per_cento. Conviene?"),
 W_("Quell'otto è il ^TAN|tan: solo gli interessi. Il prezzo vero è il ~TAEG|taeg."),
 N_("E il taeg quanto sarebbe?"),
 W_("Con duecento euro di istruttoria e due euro a rata, fa ^10,27%|dieci_virgola_ventisette_per_cento."),
 N_("Quindi alla fine quanto pago?"),
 W_("Trentasei rate da ^315_€|trecentoquindici_euro. Totale ^11.553|undicimilacinquecentocinquantatré_euro."),
 N_("Millecinquecento euro di costi, su diecimila?"),
 W_("Esatto. Guarda sempre il ~TAEG|taeg e il ~costo_totale, mai solo la rata."),
 N_("Chiaro! Prossima serie: il fondo di emergenza."),
 N_("Scrivi nei commenti la parola ^BUDGET|badget e ti mando il foglio ^gratis."),
]
CARDS=[
 dict(at=0,kind="big",tag="PRESTITO",pill="Parte 2/2",big="10.000 €",label="in 36 rate mensili",label2="tasso TAN 8,00% · esempio calcolato",col="y"),
 dict(at=1,kind="compare",tag="TAN vs TAEG",pill="Parte 2/2",sides=[dict(head="TAN",big="8,00%",sub="solo gli interessi",col="y"),dict(head="TAEG",big="?",sub="interessi + tutte le spese",col="r")],foot="Il prezzo vero è il TAEG"),
 dict(at=3,kind="big",tag="TAEG",pill="Parte 2/2",big="10,27%",label="con 200 € istruttoria e 2 € a rata",label2="altro che 8%",col="r"),
 dict(at=5,kind="bars",tag="COSTO TOTALE",pill="Parte 2/2",bars=[dict(h=0.866,val="10.000 €",name="RICEVI",col="g"),dict(h=1.0,val="11.553 €",name="PAGHI",col="r")],foot="+1.553 € di costi"),
 dict(at=7,kind="stamp",tag="VERDETTO",pill="regola d'oro",doc="CONTRATTO DI FINANZIAMENTO",big="TAEG",label="confronta il costo totale, non la rata",stamp="LEGGI IL TAEG"),
 dict(at=9,kind="END"),
]
